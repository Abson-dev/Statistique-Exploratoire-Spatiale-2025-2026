############################################################
# INSTALLATION DES PACKAGES POUR LA STATISTIQUE SPATIALE
############################################################

# Liste des packages nécessaires
packages <- c(
  "sf",          # Données spatiales vectorielles (shapefiles, GeoJSON)
  "terra",       # Données raster (grilles, images satellitaires)
  "spdep",       # Autocorrélation spatiale (Moran, LISA, poids spatiaux)
  "spatialreg",  # Modèles de régression spatiale (SAR, SEM)
  "gstat",       # Géostatistique (variogrammes, krigeage)
  "tmap",        # Cartographie thématique (statique et interactive)
  "ggplot2",     # Graphiques et cartes avec geom_sf
  "dplyr",       # Manipulation de données (filter, mutate, group_by)
  "readr",       # Import rapide de données tabulaires (CSV)
  "pastecs",     # Statistiques descriptives avancées
  "classInt",    # Discrétisation (quantiles, jenks, etc.)
  "here",        # Gestion propre des chemins de fichiers
  "rmarkdown",    # Génération de rapports (TP, comptes rendus)
  "naniar",
  "gganimate",
  "transformr"
)
install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
  }
}



invisible(lapply(packages, install_if_missing))

############################################################
# CHARGEMENT DES PACKAGES
############################################################
library(gganimate)
library(transformr)
library(sf)          
library(terra)       
library(spdep)       
library(spatialreg)  
library(gstat)       
library(tmap)        
library(ggplot2)     
library(dplyr)       
library(readr)       
library(pastecs)     
library(classInt)    
library(here)        
library(rmarkdown)   


# Observons la base de donnees ansi que sa structure
HSA <- read_csv("data/hvstat_africa_data_v1.0.csv")
unique(HSA$country)
HSA <- HSA %>%
  filter( country == c("Benin","Burkina Faso","Togo","Mali","Niger"))
unique(HSA$country)
str(HSA)
unique(HSA$season_name)
View(HSA)
###  1.
##  a) l'unite statistique de 'observtaion est un produit d'une unite administrative de second niveau representé par admin_2 lorsque celle si existe; sinon, l'unité considéré est un peoduit d'une unité administartive de premier niveau (admin_1) d'un pays pour un an donné.
# les informations fnid, admin_1 et admin_2 nous donnes les caractérisques du lieu étudié ( par exemple: pays, régions, départements...). Tandis que Product et season_name donne des informations sur le produit considéré et sa saison de culture.

## b) area nous indique sur la surface cultivée du produit considéré. Production rensigne sur la production entre le moment de semis et celui de la récolte. yield est donc le rendement défini par la fonction suivante : yield = production/ area

### 2. 
##  a) Analyse de la distribution de qc_flag par pays et par culture
dist_qc <- HSA %>% 
  select (country,product,qc_flag) %>%
  group_by(country,product)%>%
  mutate(qc_flag0 = sum(ifelse(qc_flag==0,1,0)),
         qc_flag1 = sum(ifelse(qc_flag==1,1,0)),
         qc_flag2 = sum(ifelse(qc_flag==2,1,0)))%>% 
  select (country,product,qc_flag0,qc_flag1,qc_flag2)
dist_qc <- unique(dist_qc)
save(dist_qc, file = "output/dist_qc.RData")

# A travers cette base de données, nous nous rendons compte que la culture avec le plus d'observation abérrante est le Cowpea du Niger avec 5 observation, suivi du Goussi du Benin avec 4. 
##  b) Lorsque l'on a une valeur abérante avec une faible variance, on peut remplacer les valeurs aberantes par la borne de l'écart interquartile la plus proche. Cependant, si l'on considère que un pays de référence, un variance faible, signifie que l'on peut imputer les valeurs par celle du pays de référence.
### 3. 
dist_yield <- HSA %>% 
  select (country,product,yield) %>%
  group_by(country,product)%>%
  mutate (yield_mean= mean(yield, na.rm = TRUE),
          yield_median= median(yield, na.rm = TRUE)) %>%
  select(country, product,yield_mean,yield_median)
dist_yield <- unique(dist_yield)
View(dist_yield)
save(dist_yield, file = "output/dist_yield.RData")
# Nous remarquons que le plus fort rendement en moyenne est celui de la canne à sucre au Mali avec 63t par ha. Cependant, la médiane étant supérieur à la moyenne, nous pouvons conclure qu'il existe des terres avec un rendement relativement faible, étalant la distribution vers la gauche.
# Parrallèlement, le rendement le plus faible en moyenne est celui des noix de soja, rendement de O.38 t par ha. Il est, cependant, remarquable que la distribution est totalement symmétrique.


### 4. 
unique(HSA$crop_production_system)
db_all <- HSA%>%
  filter( crop_production_system == "All (PS)")%>%
  group_by(country,product)%>%
  mutate(yield_max = max(yield, na.rm= TRUE),
         yield_min = min(yield, na.rm= TRUE),
         yield_mean = mean(yield, na.rm= TRUE))%>%
  select(country,product,yield_max,yield_min,yield_mean)
db_all <- unique(db_all)
View(db_all)
save(db_all, file = "output/db_all.RData")

db_Rainfed <- HSA%>%
  filter( crop_production_system == "Rainfed (PS)")%>%
  group_by(country,product)%>%
  mutate(yield_max = max(yield, na.rm= TRUE),
         yield_min = min(yield, na.rm= TRUE),
         yield_mean = mean(yield, na.rm= TRUE))%>%
  select(country,product,yield_max,yield_min,yield_mean)
db_Rainfed <- unique(db_Rainfed)
View(db_Rainfed)
save(db_Rainfed, file = "output/db_Rainfed.RData")

db_Plaine <- HSA%>%
  filter( crop_production_system == "Plaine/Bas-fond irrigated (PS)")%>%
  group_by(country,product)%>%
  mutate(yield_max = max(yield, na.rm= TRUE),
         yield_min = min(yield, na.rm= TRUE),
         yield_mean = mean(yield, na.rm= TRUE))%>%
  select(country,product,yield_max,yield_min,yield_mean)
db_Plaine <- unique(db_Plaine)
View(db_Plaine)
save(db_Plaine, file = "output/db_Plaine.RData")

db_Bas <- HSA%>%
  filter( crop_production_system == "Bas-fonds rainfed (PS)")%>%
  group_by(country,product)%>%
  mutate(yield_max = max(yield, na.rm= TRUE),
         yield_min = min(yield, na.rm= TRUE),
         yield_mean = mean(yield, na.rm= TRUE))%>%
  select(country,product,yield_max,yield_min,yield_mean)
db_Bas <- unique(db_Bas)
View(db_Bas)
save(db_Bas, file = "output/db_Bas.RData")


#Analyse Spatiale de la diversification avec le HHI
hhi_country_time <- HSA %>%
  filter(qc_flag == 0) %>%
  group_by(country, harvest_year, product) %>%
  summarise(prod = sum(production, na.rm = TRUE), .groups = "drop") %>%
  group_by(country, harvest_year) %>%
  mutate(p = prod / sum(prod)) %>%
  summarise(
    HHI = sum(p^2),
    .groups = "drop"
  )
View(hhi_country_time)

ggplot(
  hhi_country_time,
  aes(x = harvest_year, y = HHI, color = country, group = country)
) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  labs(
    title = "Évolution de la spécialisation agricole par pays",
    subtitle = "Année : {frame_time}",
    x = "Année",
    y = "Indice Herfindahl-Hirschman (HHI)"
  ) +
  theme_minimal() +
  transition_reveal(harvest_year)

