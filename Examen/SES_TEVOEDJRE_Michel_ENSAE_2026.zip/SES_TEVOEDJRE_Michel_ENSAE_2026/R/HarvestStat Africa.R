# packages
pkgs <- c(
  "dplyr", "tidyr", "stringr", "readr", "forcats",   
  "sf",                                             
  "spdep",
  "ggplot2", "scales", "patchwork",
  "classInt", "RColorBrewer", "viridis",
  "leaflet", "htmlwidgets",
  "cartography",
  "tmap"
)

missing <- pkgs[!(pkgs %in% installed.packages()[, "Package"])]
if (length(missing)) install.packages(missing, repos = "https://cran.r-project.org")
invisible(lapply(pkgs, library, character.only = TRUE))


# chemins
data_dir <- "data/"
out_dir  <- "outputs/"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)


# chargement des données
hvstat_geo <- st_read(paste0(data_dir, "hvstat_africa_boundary_v1.0.gpkg"),
                      quiet = TRUE)
hvstat_csv <- read.csv(paste0(data_dir, "hvstat_africa_data_v1.0.csv"),
                       stringsAsFactors = FALSE)


# Observation générale des fichiers de donnée
cat("Observation des données spatiales")
cat("  Polygones     :", nrow(hvstat_geo), "\n")
cat("  Colonnes      :", paste(names(hvstat_geo), collapse = ", "), "\n")
cat("  CRS           :", st_crs(hvstat_geo)$epsg, "\n")
cat("  Types geom    :", paste(unique(st_geometry_type(hvstat_geo))), "\n")

# Le système de projection est : WGS84 (CRS : 4326)

cat("Observation du csv")
cat("  Nombre d'observations  :", nrow(hvstat_csv), "\n")
cat("  Nombre de variables     :", ncol(hvstat_csv), "\n")
cat("  Nombre de pays          :", n_distinct(hvstat_csv$country), "\n")
cat("  Nombre de cultures      :", n_distinct(hvstat_csv$product), "\n")
cat("  Période       :", min(hvstat_csv$harvest_year), "-", max(hvstat_csv$harvest_year), "\n")

cat("\n─── Cohérence FNID ───\n")
cat("  FNID dans CSV :", n_distinct(hvstat_csv$fnid), "\n")
cat("  FNID dans GEO :", n_distinct(hvstat_geo$FNID), "\n")
cat("  En commun     :", length(intersect(hvstat_csv$fnid, hvstat_geo$FNID)), "\n")
# Tous les fnid dans le csv sont dans le geopackage, le reste constituent donc des zones non touchées
# présentes dans notre etude ou sans données agricoles.

# Partie 1 : HarvestStat Africa

# Données : HarvestStat Africa
# Zone d'étude : Afrique subsaharienne


# A : Bénin, Burkina-Faso, Mali, Togo, Niger
PAYS_A <- c("Benin", "Burkina Faso", "Mali", "Togo", "Niger")
df_a   <- hvstat_csv %>% filter(country %in% PAYS_A)
# 1) (a) Décrivons l'unité statistique d'observation en précisant le rôle des variables :
# fnid, admin_1, admin_2, product, season_name

# Il s'agit d'une culture (product) cultivée dans une zone donnée (identifié par fnid ou
# admin_1 ou admin_2) au cours d'une saison agricole (season_name) pour une année donnée.

# fnid est un identifiant géographique unique, clé de jointure csv et geopackage
# admin_1 est l'unité administrative de 1er niveau 
# admin_2 est l'unité administrative de 2e niveau
# product est la culture agricole
# season_name est la saison de culture

# (b) Expliquons la différence conceptuelle entre area, production et yield et rappeler leur
# relation théorique
# Area contient la superficie recoltée en hectares (ha).
# Production contient la quantité récoltée en tonne (t).
# Le yield contient les rendements de production en tonne par hectare (t/ha)
# La relation entre les 3 est que le yield est le ratio entre production et area.
# yield = production / area

# (2) (a) Analysons la distribution de qc_flag par pays et par culture

# pays
# qc_flag = 0 : donnée de bonne qualité
# qc_flag = 1 : valeur aberrante détectée
# qc_flag = 2 : faible variance (série temporelle suspecte)
qc_pays <- df_a %>%
  count(country, qc_flag) %>%
  group_by(country) %>%
  mutate(pct = round(n / sum(n) * 100, 2)) %>%
  ungroup()

qc_pays_wide <- qc_pays %>% 
  pivot_wider(
    names_from = qc_flag, 
    values_from = c(n, pct), 
    values_fill = 0
  )
cat("\nqc_flag par pays :\n")
print(qc_pays_wide)

# On constate que chaque pays a plus de 98% de valeurs ok.

# export du tableau
write_csv(qc_pays_wide, file.path(out_dir, "qualité_donnée_par_pays.csv"))

# cultures
qc_culture <- df_a %>%
  count(product, qc_flag) %>%
  group_by(product) %>%
  mutate(pct = round(n / sum(n) * 100, 2)) %>%
  ungroup()

qc_culture_wide <- qc_culture %>% 
  pivot_wider(
    names_from = qc_flag, 
    values_from = c(n, pct), 
    values_fill = 0
  )

cat("\nqc_flag par culture :\n")
print(qc_culture_wide)

write_csv(qc_culture_wide, file.path(out_dir, "qualité_donnée_par_culture.csv"))

# (b) Proposons une stratégie statistique pour traiter les observations avec
# qc_flag = 1 (valeurs aberrantes) et qc_flag = 2 (faible variance)
# Bilan de ces observations
cat("  0 = ok         :", sum(df_a$qc_flag == 0), "\n")
cat("  1 = aberrant   :", sum(df_a$qc_flag == 1), "\n")
cat("  2 = variance faible:", sum(df_a$qc_flag == 2), "\n")
# Il y a au total 64219  observation ok, 263  aberrantes et 232 de variance faible.
# STRATÉGIE PROPOSÉE :
#
# qc_flag = 1 (valeurs aberrantes) : On peut exclure ces observations de l'analyse.
# car elles sont signalées comme aberrantes par le producteur et elles sont peu nombreuses.
# Les garder biaise la moyenne et la variance.

# qc_flag = 2 (faible variance) : On peut les exclure totalement si l'on veut un jeu
# de données fiable.Deja elles sont peu nombreuses donc l'impact peut etre minimisé,
# ensuite elles peuvent etre des données mecaniquement reconduites d'une année à une
# autre.

# distribution initiale de la production
summary(df_a$production)

# Nettoyage
df_a_clean <- df_a %>% filter(qc_flag == 0)

# distribution finale de la production
summary(df_a_clean$production)

# La médiane initiale est 1085.0 et la médiane finale 1091.8
# La moyenne initiale est 12129.1 et la moyenne finale est 12063.9

# distribution initiale des rendements
summary(df_a$yield)

# distribution finale des rendements
summary(df_a_clean$yield)

# La difference "pourrait" etre acceptable (en confirmation de la production)

# 3) Produisons des statistiques descriptives (moyenne, médiane, quantiles, dispersion)
# de yield par : pays (country), culture (product)
# Par pays
stats_pays <- df_a %>%
  filter(!is.na(yield)) %>%
  group_by(country) %>%
  summarise(
    n        = n(),
    moyenne  = round(mean(yield), 2),
    mediane  = round(median(yield), 2),
    ecart_type = round(sd(yield), 2),
    Q1       = round(quantile(yield, 0.25), 2),
    Q3       = round(quantile(yield, 0.75), 2),
    .groups  = "drop"
  )

cat("\n  Rendement (yield) par pays :\n")
print(stats_pays)

write_csv(stats_pays, file.path(out_dir, "stats_rendement_par_pays.csv"))

# Interprétation :
# - Le Niger a la moyenne la plus élevée (≈7.7 t/ha) mais c'est trompeur :
#   sa médiane est très basse (≈0.58) et son écart-type très élevé (≈20,9).
#   Cela indique des valeurs extrêmes (cultures irriguées vs pluviales).

# Par culture
stats_culture <- df_a %>%
  filter(!is.na(yield)) %>%
  group_by(product) %>%
  summarise(
    n        = n(),
    moyenne  = round(mean(yield), 2),
    mediane  = round(median(yield), 2),
    ecart_type = round(sd(yield), 2),
    Q1       = round(quantile(yield, 0.25), 2),
    Q3       = round(quantile(yield, 0.75), 2),
    .groups  = "drop"
  )

cat("\n  Rendement (yield) par culture :\n")
print(stats_culture)

write_csv(stats_culture, file.path(out_dir, "stats_rendement_par_culture.csv"))

# 4) Comparons les distributions de rendement entre les systèmes de production
# Les systèmes de production dans ces 5 pays :
cat("  Systèmes présents :\n")
print(table(df_a$crop_production_system))

stats_systeme <- df_a %>%
  filter(!is.na(yield)) %>%
  group_by(crop_production_system) %>%
  summarise(
    n        = n(),
    moyenne  = round(mean(yield), 2),
    mediane  = round(median(yield), 2),
    ecart_type = round(sd(yield), 2),
    Q1       = round(quantile(yield, 0.25), 2),
    Q3       = round(quantile(yield, 0.75), 2),
    .groups  = "drop"
  ) %>%
  arrange(desc(mediane))

cat("\n  Statistiques par système :\n")
print(stats_systeme)

# Interprétation :
# Le système irrigué ("irrigated") a les rendements les plus élevés (médiane ≈ 17.7 t/ha)
# car il concerne surtout les cultures maraîchères et le riz irrigué.
# Le système pluvial ("Rainfed (PS)") a les rendements les plus faibles
# (médiane ≈ 0.45 t/ha), typique de l'agriculture extensive sahélienne.
# "All (PS)" agrège tous les systèmes (médiane ≈ 1.1 t/ha).
# Les bas-fonds irrigués ont un rendement intermédiaire (≈ 2.9 t/ha).

# Graphique
p_systeme <- df_a %>%
  filter(!is.na(yield), yield < 40) %>%
  ggplot(aes(x = reorder(crop_production_system, yield, FUN = median),
             y = yield, fill = crop_production_system)) +
  geom_boxplot(outlier.size = 0.3, alpha = 0.8) +
  coord_flip() +
  scale_fill_brewer(palette = "Set3", guide = "none") +
  labs(title = "Distribution du rendement par système de production",
       subtitle = paste(paste(PAYS_A, collapse = ", ")),
       x = NULL, y = "Rendement (t/ha)") +
  theme_minimal(base_size = 11)

ggsave(paste0(out_dir, "rendement_par_systeme.png"),
       p_systeme, width = 10, height = 5, dpi = 300)


# B : Sénégal
PAYS_B <- "Senegal"

# Rendement moyen par département, toutes cultures confondues
sen_yield <- hvstat_csv %>%
  filter(country == PAYS_B, qc_flag == 0, !is.na(yield)) %>%
  group_by(fnid, admin_1) %>%
  summarise(
    yield_moy = mean(yield, na.rm = TRUE),
    yield_med = median(yield, na.rm = TRUE),
    yield_sd  = sd(yield, na.rm = TRUE),
    n_obs     = n(),
    .groups   = "drop"
  )

# Jointure avec les géométries
geo_sen <- hvstat_geo %>%
  filter(ADMIN0 == PAYS_B) %>%
  left_join(sen_yield, by = c("FNID" = "fnid"))

cat("  Polygones Sénégal :", nrow(geo_sen), "\n")
cat("  Avec données yield:", sum(!is.na(geo_sen$yield_moy)), "\n")

# Sous-ensemble avec données (pour spdep)
cat("\n─── CRS initial :", st_crs(geo_sen)$epsg, "───\n")

# Pour les calculs de surface et de distance, on projette en UTM
CRS_UTM <- 32628   # UTM Zone 28N (Sénégal)
geo_sen_utm <- st_transform(geo_sen, CRS_UTM)

# Calcul des surfaces en km²
geo_sen_utm$surface_km2 <- as.numeric(st_area(geo_sen_utm)) / 1e6
cat("Surface totale (km²) :", sum(geo_sen_utm$surface_km2), "\n")

# Coordonnées des centroïdes (nécessaires pour spdep)
centroides_utm <- st_centroid(geo_sen_utm)
coords <- st_coordinates(centroides_utm)
geo_sen_utm <- geo_sen %>% filter(!is.na(yield_moy))

# 1) Indiquons comment construire la matrice de contiguité spatiale à partir de la
# variable fnid ou admin_1 (ex queen, rook, distance seuil)
# La matrice de contiguïté W
# W[i,j] = 1 si les zones i et j sont voisines, 0 sinon.

# Trois méthodes classiques :
#   a) Queen : deux zones sont voisines si elles partagent une arête
#              OU un sommet (8-connectivity)
#   b) Rook  : deux zones sont voisines si elles partagent une arête
#              uniquement (4-connectivity)
#   c) Distance seuil : deux zones sont voisines si la distance entre
#              leurs centroïdes est inférieure à un seuil d.
#
# On standardise W en ligne (style = "W") pour que chaque ligne somme à 1.
# Ainsi w[i,j] = 1/n_i où n_i est le nombre de voisins de i.


# 2) Calculons l'indice de Moran global sur ces rendements (formule + interpretation
# du signe)

# C : Analyse spatiale pertinente
# Focus Sénégal : rendement moyen du maïs
PAYS_CIBLE   <- "Senegal"
PRODUIT      <- "Maize"
PERIODE      <- 2005:2015
hvstat_clean <- hvstat_csv %>%
  filter(qc_flag == 0)
sen_mais <- hvstat_clean %>%
  filter(country == PAYS_CIBLE,
         product == PRODUIT,
         harvest_year %in% PERIODE) %>%
  group_by(fnid, admin_1) %>%
  summarise(
    yield_moy  = mean(yield, na.rm = TRUE),
    yield_sd   = sd(yield, na.rm = TRUE),
    area_moy   = mean(area, na.rm = TRUE),
    prod_moy   = mean(production, na.rm = TRUE),
    n_annees   = n_distinct(harvest_year),
    .groups = "drop"
  )

cat("\n─── Maïs Sénégal : résumé par département ───\n")
print(sen_mais)

# Jointure avec les géométries
geo_sen <- hvstat_geo %>%
  filter(ADMIN0 == PAYS_CIBLE) %>%
  left_join(sen_mais, by = c("FNID" = "fnid"))

cat("Polygones Sénégal :", nrow(geo_sen), "\n")
cat("Dont avec données :", sum(!is.na(geo_sen$yield_moy)), "\n")

# rendement maïs en Afrique de l'Ouest ---
PAYS_AO <- c("Senegal", "Mali", "Burkina Faso", "Niger", "Guinea",
             "Benin", "Togo", "Ghana", "Nigeria")

ao_mais <- hvstat_clean %>%
  filter(country %in% PAYS_AO,
         product == "Maize",
         harvest_year >= 2000) %>%
  group_by(fnid, country, admin_1) %>%
  summarise(
    yield_moy = mean(yield, na.rm = TRUE),
    prod_tot  = sum(production, na.rm = TRUE),
    .groups   = "drop"
  )

geo_ao <- hvstat_geo %>%
  filter(ADMIN0 %in% PAYS_AO) %>%
  left_join(ao_mais, by = c("FNID" = "fnid"))

# Carte du rendement moyen du maïs au Sénégal
p_sen_yield <- ggplot(geo_sen) +
  geom_sf(aes(fill = yield_moy), color = "grey40", linewidth = 0.3) +
  scale_fill_viridis_c(
    option = "C", na.value = "grey85",
    name = "Rendement\n(t/ha)",
    breaks = pretty_breaks(5)
  ) +
  labs(
    title    = paste("Rendement moyen du maïs —", PAYS_CIBLE),
    subtitle = paste0("Période ", min(PERIODE), "-", max(PERIODE),
                      " | Source : HarvestStat Africa"),
    caption  = "qc_flag = 0 uniquement"
  ) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "right",
        plot.title = element_text(face = "bold"))

ggsave(paste0(out_dir, "carte_yield_mais_senegal.png"),
       p_sen_yield, width = 10, height = 8, dpi = 300)

# Carte multi-pays Afrique de l'Ouest
p_ao <- ggplot(geo_ao) +
  geom_sf(aes(fill = yield_moy), color = "grey50", linewidth = 0.2) +
  scale_fill_viridis_c(
    option = "D", na.value = "grey90",
    name = "Rendement\nmaïs (t/ha)"
  ) +
  labs(
    title = "Rendement moyen du maïs — Afrique de l'Ouest",
    subtitle = "Période 2000+",
    caption = "Source : HarvestStat Africa"
  ) +
  theme_minimal(base_size = 11)

ggsave(paste0(out_dir, "carte_yield_mais_afrique_ouest.png"),
       p_ao, width = 12, height = 8, dpi = 300)

# Taille proportionnelle à la production
png(paste0(out_dir, "symboles_proportionnels_senegal.png"),
    width = 1000, height = 800)
par(mar = c(0, 0, 2, 0))
plot(st_geometry(geo_sen), col = "#F5DEB3", border = "grey60",
     main = paste("Production moyenne de maïs —", PAYS_CIBLE))

# Filtrer les polygones avec données
geo_sen_data <- geo_sen %>% filter(!is.na(prod_moy))
if (nrow(geo_sen_data) > 0) {
  propSymbolsLayer(
    x       = geo_sen_data,
    var     = "prod_moy",
    inches  = 0.2,
    col     = adjustcolor("darkgreen", alpha.f = 0.6),
    border  = "grey30",
    legend.title.txt = "Production (t)"
  )
}
dev.off()