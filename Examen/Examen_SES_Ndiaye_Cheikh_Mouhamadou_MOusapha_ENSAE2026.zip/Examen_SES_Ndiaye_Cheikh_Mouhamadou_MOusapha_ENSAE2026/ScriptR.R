
# HARVESTSTAT AFRICA – PARTIE 1 & ANALYSE SPATIALE



# QUESTION 1 : UNITE STATISTIQUE D’OBSERVATION

# L’unité statistique d’observation correspond à une estimation
# agricole pour un produit donné, dans une unité administrative
# identifiée par fnid, pour une saison (season_name) et une année.
#
# - fnid     : identifiant spatial unique servant de clé de jointure
#              entre les données agricoles et les limites administratives
# - admin_1  : niveau administratif 1 (région), utilisé pour les analyses
#              et agrégations régionales
# - admin_2  : niveau administratif 2 (département), niveau spatial plus fin
# - product  : culture observée (Maize, Rice, Sorghum, etc.)
# - season_name : saison agricole (ex : Main, Secondary), permettant
#                 l’analyse intra-annuelle de la production


# PACKAGES 
library(dplyr)
library(ggplot2)
library(sf)
library(spdep)

# 1. CHARGEMENT DES DONNÉES 
stats <- read.csv("C:/Users/moust/Downloads/hvstat_africa_data_v1.0.csv")


# QUESTION 2 : DIFFERENCE ENTRE AREA, PRODUCTION ET YIELD
# -----------------------------------------------------
# - area (ha)        : superficie cultivée pour une culture donnée
# - production (t)  : quantité totale récoltée
# - yield (t/ha)    : rendement agricole, mesure de la productivité
#
# Relation théorique fondamentale :
# production = area × yield
# yield = production / area
#
# Le rendement permet de comparer les performances agricoles
# indépendamment de la taille des surfaces cultivées.


# -----------------------------------------------------
# QUESTION 3 : DISTRIBUTION DU QC_FLAG PAR PAYS ET PAR CULTURE
# -----------------------------------------------------
qc_distribution <- stats %>%
  group_by(country, product, qc_flag) %>%
  summarise(n = n(), .groups = "drop")

qc_distribution

# Interpretation du qc_flag :
# - qc_flag = 0 : données fiables
# - qc_flag = 1 : valeurs aberrantes (outliers)
# - qc_flag = 2 : faible variance (peu de variabilité)
#
# Strategie statistique :
# • qc_flag = 1 :
#   - verifier la coherence area / production / yield
#   - winsorisation, transformation logarithmique ou exclusion
# • qc_flag = 2 :
#   - conserver pour analyses agrégées
#   - exclure des modèles explicatifs
#   - regrouper sur plusieurs années
# -----------------------------------------------------

# -----------------------------------------------------
# QUESTION 4 : STATISTIQUES DESCRIPTIVES DU RENDEMENT
# (PAR PAYS ET PAR CULTURE)
# -----------------------------------------------------
countries <- c(
  "Benin", "Burkina Faso", "Cote d'Ivoire",
  "Mali", "Togo", "Niger"
)

yield_desc <- stats %>%
  filter(
    country %in% countries,
    qc_flag == 0
  ) %>%
  group_by(country, product) %>%
  summarise(
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    q25 = quantile(yield, 0.25, na.rm = TRUE),
    q75 = quantile(yield, 0.75, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    .groups = "drop"
  )

yield_desc

# Ces statistiques permettent de comparer :
# - le niveau moyen des rendements
# - la dispersion
# - l’asymétrie des distributions
# entre pays et entre cultures.

# QUESTION 5 : COMPARAISON DES RENDEMENTS
# ENTRE LES SYSTEMES DE PRODUCTION
# -----------------------------------------------------
ggplot(
  stats %>% filter(qc_flag == 0),
  aes(crop_production_system, yield)
) +
  geom_boxplot() +
  labs(
    title = "Distribution des rendements par système de production",
    x = "Système de production",
    y = "Rendement (t/ha)"
  ) +
  theme_minimal()

# L’analyse repose sur la comparaison :
# - des médianes
# - de la dispersion interquartile

# afin d’identifier les systèmes les plus performants.

# PARTIE 2 : ANALYSE SPATIALE
# Hypothèse : rendement moyen du maïs par admin_1
# calculé sur la période 2015–2020 au Sénégal
# -----------------------------------------------------

# -----------------------------------------------------
# QUESTION 6 : MATRICE DE CONTIGUITE SPATIALE
# -----------------------------------------------------
# A partir de admin_1, on peut construire une matrice
# de contiguïté spatiale selon plusieurs critères :
#
# - Queen : deux régions sont voisines si elles partagent
#           une frontière ou un sommet
# - Rook  : partage d’une frontière uniquement
# - Distance seuil : voisins si la distance entre centroïdes
#                    est inférieure à un seuil donné
#

# -----------------------------------------------------
# QUESTION 7 : INDICE DE MORAN GLOBAL
# -----------------------------------------------------
# Formule :
# I = (n / W) * [ Σi Σj wij (xi − x̄)(xj − x̄) ] / Σi (xi − x̄)²
#
# où :
# - wij est la matrice de poids spatiaux
# - xi est le rendement dans la région i
# - x̄ est le rendement moyen
#
# Calcul de l’indice de Moran global :
# -----------------------------------------------------

