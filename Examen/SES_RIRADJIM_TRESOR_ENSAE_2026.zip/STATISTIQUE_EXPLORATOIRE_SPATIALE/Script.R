# Packages et librairies nécessaires

install.packages(c("tidyverse", "sf"))
library(tidyverse)
library(sf)

# Je définis le chemin vers mon dossier
data_path <- "/Users/HP/Downloads"

# J'importe mes données
hvstat_data <- read_csv(
  file.path(data_path, "hvstat_africa_data_v1.0.csv")
)

hvstat_boundary <- st_read(
  file.path(data_path, "hvstat_africa_boundary_v1.0.gpkg")
)


# Je fais quelques vérifications et voir si le géopackage a plusieurs couches
glimpse(hvstat_data)
head(hvstat_data)

st_layers(file.path(data_path, "hvstat_africa_boundary_v1.0.gpkg"))

plot(st_geometry(hvstat_boundary))

# J'explore mes variables et les labels géographiques meme si c'est décrit dans le readme
names(hvstat_data)

# Je fais la Jointure des données agricoles et géométrie
#hvstat_sf <- hvstat_boundary %>%
  #left_join(hvstat_data, by = "fnid")

# Je vérifie les valeurs manquantes et leurs pourcentages
View(hvstat_data)
colSums(is.na(hvstat_data))
missing_pct <- colMeans(is.na(hvstat_data)) * 100
sort(missing_pct, decreasing = TRUE)


# PARTIE 1-HarvestStat Africa

# Unité statistique d’observation

Ici,l’unité statistique d’observation correspond à une combinaison spatiale,temporelle et agricole, qui peut etre définie par :
une unité géographique identifiable par fnid (qui est une unité administrative admin_1 ou admin_2 selon les pays);
un pays (country) à l'exemple de la Côte d’Ivoire, le Mali, le Togo ou le Niger;
une culture agricole (product);
une saison de culture (season_name);
une année de récolte (harvest_year).

On peut ainsi dire que chaque observation représente donc la production agricole d’une culture donnée, pour une saison et une année spécifiques, dans une unité administrative précise.


# Role des variables

- fnid est l'identifiant spatial qui est unique et qui permet de voir dans le temps;

- admin_1 et admin_2 sont les niveaux administratifs qui permettent l’analyse spatiale;

- product permet de différencier les systèmes de culture;

- season_name permet de tenir compte de la saison agricole.


# b – Différence conceptuelle entre area, production et yield

Les variables area, production et yield décrivent trois déterminants de la production agricole à savoir:

- area (superficie récoltée), est un indicateur qui détermine la superfice de la surface;

- production, est le volume total produit et est un indicateur alimentaire;

- yield est le rendement et indique l'intensité et l'efficacité de la production.

#D'abord, la relation théorique qui les lie est : yield = production / area

# On peut observer que deux régions peuvent avoir la même production avec des superficies très différentes,
# ainsi, le rendement va nous permettre de comparer la performance culturelle (agricole) sans tenir compte de la taille des chaamps.








# 2. Analysons la distribution de qc_flag par pays et par culture

# Je fixe mes pays pour travailler

library(dplyr)
library(tidyr)
library(ggplot2)

hv_mnt <- hvstat_data %>%
  filter(country %in% c("Mali", "Niger", "Togo"))

# Je vois la distribution de qc_flag selon les pays
# Leurs effectifs
qc_by_country <- hv_mnt %>%
  count(country, qc_flag)

qc_by_country

# Je calcule leurs pourcentages
qc_by_country_pct <- hv_mnt %>%
  count(country, qc_flag) %>%
  group_by(country) %>%
  mutate(pct = 100 * n / sum(n))

qc_by_country_pct

# Je représente en graphique pour la visualisation
ggplot(qc_by_country_pct,
       aes(x = country, y = pct, fill = factor(qc_flag))) +
  geom_col() +
  labs(
    x = "Pays",
    y = "Pourcentage des observations",
    fill = "qc_flag"
  ) +
  theme_minimal()

# Je vois la distribution de qc_flag par culture
# Surtout celles qui dominent 
top_products <- hv_mnt %>%
  count(product, sort = TRUE) %>%
  slice_head(n = 10) %>%
  pull(product)

# J'affiche les effectifs par culture
qc_by_product <- hv_mnt %>%
  filter(product %in% top_products) %>%
  count(product, qc_flag)

qc_by_product

# J'affiche les pourcentages par culture
qc_by_product_pct <- hv_mnt %>%
  filter(product %in% top_products) %>%
  count(product, qc_flag) %>%
  group_by(product) %>%
  mutate(pct = 100 * n / sum(n))

qc_by_product_pct

# J'affiche pour mieux voir 
ggplot(qc_by_product_pct,
       aes(x = product, y = pct, fill = factor(qc_flag))) +
  geom_col() +
  coord_flip() +
  labs(
    x = "Culture",
    y = "Pourcentage des observations",
    fill = "qc_flag"
  ) +
  theme_minimal()


# D'après nos descriptions à la question1, il est important de faire le lien entre qc_flag et les variables agricoles en sortant quelques statistiques
hv_mnt %>%
  group_by(qc_flag) %>%
  summarise(
    n = n(),
    mean_yield = mean(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    mean_area = mean(area, na.rm = TRUE),
    mean_production = mean(production, na.rm = TRUE)
  )

# D'après nos statistiques, nous repondons donc que : 

# la variable qc_flag montre une très bonne qualité globale des données agricoles pour le Mali, le Niger et le Togo.
# Dans les trois pays, plus de 99 % des observations ont un qc_flag = 0.
# Les valeurs aberrantes (qc_flag = 1) ne sont pas très fréquentes : Mali(0,83%), Niger(0,31%) et Togo(0,22%)
# Les observations qui varient faiblement (qc_flag = 2) sont presque inexistantes et concernent seulement le Niger (0,12%) et le Togo (0,18%).

# En ce qui concerne les culture, les principales cultures (niébé, maïs, arachide, manioc, voandzou) ont au moins 99 % des observations qc_flag = 0,
# les valeurs aberrantes restent inférieures à 1 % dans tous les cas,
# les cas de faible variance sont rares et concernent essentiellement le maïs.

# L'on se rend compte que les observations avec qc_flag = 0 présentent des rendements moyens modérés et une dispersion acceptable.
# Les observations avec qc_flag = 1 affichent des rendements moyens très élevés et une variance extrêmement forte.
# Les observations avec qc_flag = 2 se caractérisent par une faible dispersion.

# Au regard de ces résultats, la stratégie statistique qu'on peut adopter est la suivante:
# On peut onserver les observations avec qc_flag = 0 pour toutes les analyses principales.
# On peut exclure les observations avec qc_flag = 1 des analyses de rendement et de variabilité pour éviter une forte influence des valeurs aberrantes.
# On peut utiliser avec prudence les observations avec qc_flag = 2, en les excluant des analyses de dispersion, mais on pourra les conserver pour des analyses descriptives simples par exemple.


# 3. Statistiques descriptives du rendement (yield) par pays et par culture

# Affichons les statistiques du rendement par pays
yield_stats_country <- hv_mnt %>%
  summarise(
    n_total = n(),
    n_yield_non_na = sum(!is.na(yield)),
    pct_yield_na = 100 * mean(is.na(yield)),
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    p25_yield = quantile(yield, 0.25, na.rm = TRUE),
    p75_yield = quantile(yield, 0.75, na.rm = TRUE),
    min_yield = min(yield, na.rm = TRUE),
    max_yield = max(yield, na.rm = TRUE)
  )

# C'est mieux de grouper par pays
yield_stats_country <- hv_mnt %>%
  group_by(country) %>%
  summarise(
    n_total = n(),
    n_yield_non_na = sum(!is.na(yield)),
    pct_yield_na = 100 * mean(is.na(yield)),
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    p25_yield = quantile(yield, 0.25, na.rm = TRUE),
    p75_yield = quantile(yield, 0.75, na.rm = TRUE),
    min_yield = min(yield, na.rm = TRUE),
    max_yield = max(yield, na.rm = TRUE),
    .groups = "drop"
  )

# Pour les cultures (mais dans chauque pays)
yield_stats_country_product <- hv_mnt %>%
  group_by(country, product) %>%
  summarise(
    n = n(),
    n_yield_non_na = sum(!is.na(yield)),
    pct_yield_na = 100 * mean(is.na(yield)),
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    p25_yield = quantile(yield, 0.25, na.rm = TRUE),
    p75_yield = quantile(yield, 0.75, na.rm = TRUE),
    .groups = "drop"
  )

# On va prendre les plus fréquentes
yield_stats_country_product_ok <- yield_stats_country_product %>%
  filter(n_yield_non_na >= 10)


# Comme on a qc_flag = 1 gonfle les rendements, on va faire une table qc_flag==0 uniquement.
yield_stats_country_qc0 <- hv_mnt %>%
  filter(qc_flag == 0) %>%
  group_by(country) %>%
  summarise(
    n = n(),
    n_yield_non_na = sum(!is.na(yield)),
    pct_yield_na = 100 * mean(is.na(yield)),
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    p25_yield = quantile(yield, 0.25, na.rm = TRUE),
    p75_yield = quantile(yield, 0.75, na.rm = TRUE),
    .groups = "drop"
  )

# Pour exporter
write.csv(yield_stats_country,
          "yield_stats_country.csv",
          row.names = FALSE)

write.csv(yield_stats_country_product,
          "yield_stats_country_product.csv",
          row.names = FALSE)

write.csv(yield_stats_country_qc0,
          "yield_stats_country_qc0.csv",
          row.names = FALSE)
getwd()

# Les statistiques descriptives des rendements que la part est
# d'environ 5,8 % au Mali, 0,9 % au Niger et 1,2 % au Togo.Les rendements médians sont relativement proches entre les pays et inférieurs à 1 t/ha pour la majorité des cultures vivrières (0,83 t/ha au Mali, 0,58 t/ha au Niger et 0,95 t/ha au Togo).
# Mais, les rendements moyens sont plus élevés, en particulier au Niger (environ 7,7 t/ha), contre environ 1,7 t/ha au Mali et au Togo. Les écarts-types sont élevés, surtout au Niger (environ 21 t/ha). De ces analyses il ressort que la médiane et les quantiles sont plus représentatifs que la moyenne pour comparer les performances agricoles entre pays et cultures.


# 4.Comparaison des rendements par système de production

# Avec les resultats de Q2-Q3, on retire les valeurs aberrrantes
hv_mnt_qc0 <- hv_mnt %>%
  filter(qc_flag == 0)


# On sort les statistiques descriptives par pays et système de production
yield_stats_system <- hv_mnt_qc0 %>%
  group_by(country, crop_production_system) %>%
  summarise(
    n = n(),
    n_yield_non_na = sum(!is.na(yield)),
    pct_yield_na = 100 * mean(is.na(yield)),
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    sd_yield = sd(yield, na.rm = TRUE),
    p25_yield = quantile(yield, 0.25, na.rm = TRUE),
    p75_yield = quantile(yield, 0.75, na.rm = TRUE),
    .groups = "drop"
  )


ggplot(hv_mnt_qc0,
       aes(x = crop_production_system, y = yield)) +
  geom_boxplot() +
  facet_wrap(~ country, scales = "free_y") +
  labs(
    x = "Système de production",
    y = "Rendement (t/ha)"
  ) +
  theme_minimal()


write.csv(yield_stats_system,
          "Q4_yield_by_production_system.csv",
          row.names = FALSE)


# On constate des différences très marquées, en particulier au Niger. Dans ce pays, l’agriculture irriguée présente des rendements nettement plus élevés, avec une médiane d’environ 17,7 t/ha, contre seulement 0,36 t/ha pour les systèmes pluviaux
# et une dispersion beaucoup plus forte en irrigation (écart-type ≈ 24,5 t/ha). À l’inverse, les systèmes pluviaux au Niger affichent des rendements faibles et très concentrés. Au Mali et au Togo, les données ne distinguent pas les systèmes de production,
# mais les rendements médians restent faibles, respectivement autour de 0,83 t/ha et 0,95 t/ha.




# Pour cette partie nous considérerons le NIGER, que nous justifions par un très grand nombre d’observations, une diversité agricole et climatique.

# Focus sur le Niger (on filtre et on affiche la carte pour s'assurer)

library(dplyr)
library(sf)

hvstat_boundary2 <- hvstat_boundary %>%
  rename(
    fnid = FNID,
    admin_0 = ADMIN0,
    admin_1 = ADMIN1,
    admin_2 = ADMIN2
  )


fnid_niger <- hvstat_data %>%
  filter(country == "Niger") %>%
  distinct(fnid)

boundary_niger <- hvstat_boundary2 %>%
  semi_join(fnid_niger, by = "fnid")


nrow(boundary_niger)
plot(st_geometry(boundary_niger))


# On aggrege les rendements par unité spatiale (fnid) toujours en gardant qc_flag == 0
hv_niger <- hvstat_data %>%
  filter(country == "Niger", qc_flag == 0)

yield_niger_admin <- hv_niger %>%
  group_by(fnid) %>%
  summarise(
    mean_yield = mean(yield, na.rm = TRUE),
    median_yield = median(yield, na.rm = TRUE),
    n = n(),
    .groups = "drop"
  )


# On procède à la jointure
niger_sf <- boundary_niger %>%
  left_join(yield_niger_admin, by = "fnid")


# 1) Taille des frontières filtrées (combien d’unités spatiales au Niger)
nrow(boundary_niger)


# 2) Taille de la table de stats (combien de fnid ont des stats de rendement)
nrow(yield_niger_admin)

# 3) Vérifier la jointure : combien de polygones sans rendement moyen (NA)
sum(is.na(niger_sf$mean_yield))

# 4) Vérifier un aperçu (les premières lignes)
niger_sf %>%
  st_drop_geometry() %>%
  select(fnid, admin_0, admin_1, admin_2, n, mean_yield, median_yield) %>%
  head(10)


# On représente les cartes du rendement moyen et de la médiane
library(ggplot2)

ggplot(niger_sf) +
  geom_sf(aes(fill = mean_yield), color = NA) +
  labs(
    title = "Niger – Rendement moyen (qc_flag = 0)",
    fill = "Rendement moyen\n(t/ha)"
  ) +
  theme_minimal()


# Pour la médiane pour ouvrir les yeux
ggplot(niger_sf) +
  geom_sf(aes(fill = median_yield), color = NA) +
  labs(
    title = "Niger – Rendement médian (qc_flag = 0)",
    fill = "Rendement médian\n(t/ha)"
  ) +
  theme_minimal()


# les statistiques nécessaires
yield_niger_export <- niger_sf %>%
  st_drop_geometry() %>%
  select(fnid, admin_0, admin_1, admin_2, n, mean_yield, median_yield)

write.csv(yield_niger_export, "Niger_yield_stats_by_fnid.csv", row.names = FALSE)



# Allons maintenant à l'a utocorrélation spatiale de Moran’s I (global)
# On prépare le voisinage (k plus proche voisins)
install.packages(c("spdep"))

library(spdep)
library(sf)

cent <- st_centroid(niger_sf)
coords <- st_coordinates(cent)

nb <- knn2nb(knearneigh(coords, k = 4))
lw <- nb2listw(nb, style = "W")

# On le teste sur le rendement médian
moran_med <- moran.test(niger_sf$median_yield, lw, na.action = na.exclude)
moran_med



# De tout ce qui précède sur Moran appliqué au rendement médian par unité administrative met en évidence une autocorrélation spatiale positive.
# La valeur de l’indice de Moran est d'environ 0,38. ce qui permet de rejeter très clairement l’hypothèse d’une distribution spatiale aléatoire des rendements. Cela signifie que les unités administratives voisines tendent à présenter des niveaux de rendement similaires.

# Calculons des indicateurs locaux de Moran (toujours avec les rendements moyens)

lisa_med <- localmoran(niger_sf$median_yield, lw)

# Vérifier les colonnes (optionnel)
colnames(lisa_med)

# On ajoute les resultats à niger
niger_sf$lisa_I <- lisa_med[, "Ii"]
niger_sf$lisa_z <- lisa_med[, "Z.Ii"]
niger_sf$lisa_p <- lisa_med[, "Pr(z != E(Ii))"]

# On observe vite fait les stats
summary(niger_sf$lisa_p)

# On va maintenant construire les clusters HH, LL, HL et LH

lag_med <- lag.listw(lw, niger_sf$median_yield)
m <- mean(niger_sf$median_yield, na.rm = TRUE)

niger_sf$lisa_cluster <- "Non significatif"
sig <- niger_sf$lisa_p < 0.05

niger_sf$lisa_cluster[sig & niger_sf$median_yield >= m & lag_med >= m] <- "Haut-Haut"
niger_sf$lisa_cluster[sig & niger_sf$median_yield <  m & lag_med <  m] <- "Bas-Bas"
niger_sf$lisa_cluster[sig & niger_sf$median_yield >= m & lag_med <  m] <- "Haut-Bas"
niger_sf$lisa_cluster[sig & niger_sf$median_yield <  m & lag_med >= m] <- "Bas-Haut"

# On regroupe sous forme de tableau
table(niger_sf$lisa_cluster)

install.packages(c("dplyr"))
library(dplyr)
library(sf)

niger_sf %>%
  st_drop_geometry() %>%
  select(admin_1, admin_2, median_yield, lisa_cluster, lisa_p) %>%
  arrange(lisa_p) %>%
  head(15)

# Et on exporte
lisa_table <- niger_sf %>%
  st_drop_geometry() %>%
  select(
    admin_0,
    admin_1,
    admin_2,
    median_yield,
    lisa_cluster,
    lisa_p
  )

head(lisa_table)

write.csv(
  lisa_table,
  "Niger_LISA_results.csv",
  row.names = FALSE
)

# L’analyse locale de l’autocorrélation spatiale (LISA) montre que 
# Sur les 64 unités administratives analysées, seules trois unités forment des clusters de type Haut–Haut, 
# toutes situées dans la région d’Agadez, à savoir Bilma, Iferouane et Arlit. 
# Ces dernières présentent des rendements médians élevés (respectivement 18,6 t/ha, 14,4 t/ha et 8,6 t/ha) et sont entourées de zones voisines également productives, 
# avec des p-values très faibles (jusqu’à 5,7 × 10⁻¹² pour Bilma).
# Mais la grande majorité des unités (61 sur 64) ne montre pas d’autocorrélation locale significative, et aucun cluster de type Bas–Bas n’est détecté.




# Section5 : Discussion
L’étude basée sur les données ERA5 peut être améliorée de plusieurs façons. Tout d’abord, les données ERA5 ont une résolution spatiale assez large, ce qui signifie qu’elles ne représentent pas toujours bien les variations climatiques locales importantes pour l’agriculture.
Pour améliorer l’analyse, il est possible de combiner ERA5 avec d’autres sources de données, comme les données satellitaires de précipitations ou les données des stations météorologiques locales, afin d’obtenir des informations plus précises.
Ensuite, il est préférable d’utiliser des périodes de temps adaptées aux saisons agricoles plutôt que des moyennes annuelles, car les cultures réagissent surtout aux conditions climatiques pendant leur période de croissance.
Enfin, l’utilisation de méthodes statistiques et spatiales plus avancées permettrait de mieux analyser les différences régionales et de mieux comprendre l’influence du climat sur la production agricole. Ces améliorations rendraient l’étude plus fiable et plus utile pour l’analyse des systèmes agricoles.

