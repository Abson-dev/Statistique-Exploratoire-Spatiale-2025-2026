#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALYSE EXHAUSTIVE DES DONNÉES HARVESTSTAT AFRICA
==================================================
Analyse complète des statistiques agricoles infranationales 
pour l'Afrique subsaharienne (1980-2022)

Auteur: Claude
Date: 2026-02-06
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gpd
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Configuration de l'affichage
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_rows', 100)

print("="*80)
print("ANALYSE HARVESTSTAT AFRICA - STATISTIQUES AGRICOLES SUBSAHARIENNES")
print("="*80)
print()

# ============================================================================
# ÉTAPE 1: CHARGEMENT DES DONNÉES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 1: CHARGEMENT DES DONNÉES")
print("="*80)

# Chemins des fichiers
data_path = Path('/mnt/user-data/uploads')
csv_file = data_path / 'hvstat_africa_data_v1.0.csv'
gpkg_file = data_path / 'hvstat_africa_boundary_v1.0.gpkg'

# Chargement du CSV
print("\n1.1 Chargement du fichier CSV...")
print(f"    Fichier: {csv_file}")
try:
    df = pd.read_csv(csv_file, low_memory=False)
    print(f"    ✓ Chargement réussi")
    print(f"    Nombre de lignes: {len(df):,}")
    print(f"    Nombre de colonnes: {len(df.columns)}")
except FileNotFoundError:
    print(f"    ✗ ERREUR: Fichier non trouvé")
    print(f"    Veuillez placer le fichier dans: {data_path}")
    exit(1)
except Exception as e:
    print(f"    ✗ ERREUR lors du chargement: {e}")
    exit(1)

# Chargement du GeoPackage
print("\n1.2 Chargement du fichier GeoPackage...")
print(f"    Fichier: {gpkg_file}")
try:
    gdf = gpd.read_file(gpkg_file)
    print(f"    ✓ Chargement réussi")
    print(f"    Nombre d'entités géographiques: {len(gdf):,}")
    print(f"    Système de coordonnées: {gdf.crs}")
except FileNotFoundError:
    print(f"    ⚠ Fichier géographique non trouvé")
    gdf = None
except Exception as e:
    print(f"    ⚠ Erreur lors du chargement géographique: {e}")
    gdf = None

# ============================================================================
# ÉTAPE 2: EXPLORATION INITIALE DES DONNÉES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 2: EXPLORATION INITIALE DES DONNÉES")
print("="*80)

print("\n2.1 Aperçu des premières lignes:")
print("-" * 80)
print(df.head(10))

print("\n2.2 Aperçu des dernières lignes:")
print("-" * 80)
print(df.tail(10))

print("\n2.3 Informations sur les colonnes:")
print("-" * 80)
print(df.info())

print("\n2.4 Types de données par colonne:")
print("-" * 80)
for col in df.columns:
    print(f"    {col:30s} : {df[col].dtype}")

# ============================================================================
# ÉTAPE 3: STATISTIQUES DESCRIPTIVES GÉNÉRALES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 3: STATISTIQUES DESCRIPTIVES GÉNÉRALES")
print("="*80)

print("\n3.1 Statistiques pour les variables numériques:")
print("-" * 80)
print(df.describe())

print("\n3.2 Statistiques détaillées pour les variables clés:")
print("-" * 80)

# Superficie (area)
if 'area' in df.columns:
    print("\n    SUPERFICIE (ha):")
    print(f"        Moyenne: {df['area'].mean():,.2f} ha")
    print(f"        Médiane: {df['area'].median():,.2f} ha")
    print(f"        Écart-type: {df['area'].std():,.2f} ha")
    print(f"        Minimum: {df['area'].min():,.2f} ha")
    print(f"        Maximum: {df['area'].max():,.2f} ha")
    print(f"        Q1 (25%): {df['area'].quantile(0.25):,.2f} ha")
    print(f"        Q3 (75%): {df['area'].quantile(0.75):,.2f} ha")
    print(f"        Valeurs manquantes: {df['area'].isna().sum():,} ({df['area'].isna().sum()/len(df)*100:.2f}%)")

# Production
if 'production' in df.columns:
    print("\n    PRODUCTION (tonnes):")
    print(f"        Moyenne: {df['production'].mean():,.2f} t")
    print(f"        Médiane: {df['production'].median():,.2f} t")
    print(f"        Écart-type: {df['production'].std():,.2f} t")
    print(f"        Minimum: {df['production'].min():,.2f} t")
    print(f"        Maximum: {df['production'].max():,.2f} t")
    print(f"        Q1 (25%): {df['production'].quantile(0.25):,.2f} t")
    print(f"        Q3 (75%): {df['production'].quantile(0.75):,.2f} t")
    print(f"        Valeurs manquantes: {df['production'].isna().sum():,} ({df['production'].isna().sum()/len(df)*100:.2f}%)")

# Rendement
if 'yield' in df.columns:
    print("\n    RENDEMENT (t/ha):")
    print(f"        Moyenne: {df['yield'].mean():,.2f} t/ha")
    print(f"        Médiane: {df['yield'].median():,.2f} t/ha")
    print(f"        Écart-type: {df['yield'].std():,.2f} t/ha")
    print(f"        Minimum: {df['yield'].min():,.2f} t/ha")
    print(f"        Maximum: {df['yield'].max():,.2f} t/ha")
    print(f"        Q1 (25%): {df['yield'].quantile(0.25):,.2f} t/ha")
    print(f"        Q3 (75%): {df['yield'].quantile(0.75):,.2f} t/ha")
    print(f"        Valeurs manquantes: {df['yield'].isna().sum():,} ({df['yield'].isna().sum()/len(df)*100:.2f}%)")

# ============================================================================
# ÉTAPE 4: ANALYSE DES VALEURS MANQUANTES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 4: ANALYSE DES VALEURS MANQUANTES")
print("="*80)

print("\n4.1 Nombre de valeurs manquantes par colonne:")
print("-" * 80)
missing_data = pd.DataFrame({
    'Colonne': df.columns,
    'Valeurs_manquantes': df.isna().sum(),
    'Pourcentage': (df.isna().sum() / len(df) * 100).round(2)
})
missing_data = missing_data.sort_values('Valeurs_manquantes', ascending=False)
print(missing_data.to_string(index=False))

print("\n4.2 Lignes complètement vides:")
print(f"    Nombre de lignes sans aucune donnée: {df.isna().all(axis=1).sum()}")

print("\n4.3 Lignes avec au moins une valeur manquante:")
print(f"    Nombre: {df.isna().any(axis=1).sum():,} ({df.isna().any(axis=1).sum()/len(df)*100:.2f}%)")

# ============================================================================
# ÉTAPE 5: ANALYSE DES VARIABLES CATÉGORIELLES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 5: ANALYSE DES VARIABLES CATÉGORIELLES")
print("="*80)

# Pays
if 'country' in df.columns:
    print("\n5.1 Distribution par PAYS:")
    print("-" * 80)
    country_counts = df['country'].value_counts()
    country_pct = (df['country'].value_counts(normalize=True) * 100).round(2)
    country_stats = pd.DataFrame({
        'Pays': country_counts.index,
        'Nombre_enregistrements': country_counts.values,
        'Pourcentage': country_pct.values
    })
    print(f"    Nombre total de pays: {df['country'].nunique()}")
    print("\n    Top 10 pays par nombre d'enregistrements:")
    print(country_stats.head(10).to_string(index=False))
    print("\n    Distribution complète:")
    print(country_stats.to_string(index=False))

# Code pays
if 'country_code' in df.columns:
    print("\n5.2 Codes pays ISO:")
    print("-" * 80)
    print(f"    Nombre de codes uniques: {df['country_code'].nunique()}")
    print(f"    Codes: {sorted(df['country_code'].dropna().unique())}")

# Cultures
if 'product' in df.columns:
    print("\n5.3 Distribution par CULTURE:")
    print("-" * 80)
    product_counts = df['product'].value_counts()
    product_pct = (df['product'].value_counts(normalize=True) * 100).round(2)
    product_stats = pd.DataFrame({
        'Culture': product_counts.index,
        'Nombre_enregistrements': product_counts.values,
        'Pourcentage': product_pct.values
    })
    print(f"    Nombre total de cultures: {df['product'].nunique()}")
    print("\n    Top 20 cultures:")
    print(product_stats.head(20).to_string(index=False))
    
    # Cultures céréalières principales
    cereales_principales = ['wheat', 'maize', 'rice', 'sorghum', 'barley', 'millet', 'fonio',
                           'Wheat', 'Maize', 'Rice', 'Sorghum', 'Barley', 'Millet', 'Fonio',
                           'blé', 'maïs', 'riz', 'sorgho', 'orge', 'mil']
    print("\n    Cultures céréalières principales mentionnées:")
    for cereal in cereales_principales:
        if cereal in df['product'].values:
            count = (df['product'] == cereal).sum()
            pct = count / len(df) * 100
            print(f"        {cereal:20s}: {count:8,} enregistrements ({pct:5.2f}%)")

# Unités administratives
if 'admin_1' in df.columns:
    print("\n5.4 Unités administratives niveau 1:")
    print("-" * 80)
    print(f"    Nombre d'unités admin_1: {df['admin_1'].nunique()}")
    print(f"    Top 10:")
    admin1_counts = df['admin_1'].value_counts().head(10)
    for admin, count in admin1_counts.items():
        print(f"        {admin:40s}: {count:8,} enregistrements")

if 'admin_2' in df.columns:
    print("\n5.5 Unités administratives niveau 2:")
    print("-" * 80)
    print(f"    Nombre d'unités admin_2: {df['admin_2'].nunique()}")
    print(f"    Top 10:")
    admin2_counts = df['admin_2'].value_counts().head(10)
    for admin, count in admin2_counts.items():
        print(f"        {admin:40s}: {count:8,} enregistrements")

# Saisons
if 'season_name' in df.columns:
    print("\n5.6 Saisons de culture:")
    print("-" * 80)
    print(f"    Nombre de saisons uniques: {df['season_name'].nunique()}")
    season_counts = df['season_name'].value_counts()
    for season, count in season_counts.items():
        pct = count / len(df) * 100
        print(f"        {season:30s}: {count:8,} ({pct:5.2f}%)")

# Systèmes de production
if 'crop_production_system' in df.columns:
    print("\n5.7 Systèmes de production:")
    print("-" * 80)
    print(f"    Nombre de systèmes: {df['crop_production_system'].nunique()}")
    system_counts = df['crop_production_system'].value_counts()
    for system, count in system_counts.items():
        pct = count / len(df) * 100
        print(f"        {system:30s}: {count:8,} ({pct:5.2f}%)")

# Quality Control Flag
if 'qc_flag' in df.columns:
    print("\n5.8 Indicateurs de qualité (QC Flag):")
    print("-" * 80)
    qc_counts = df['qc_flag'].value_counts()
    print("    Signification:")
    print("        0 = OK (données valides)")
    print("        1 = Valeur aberrante détectée")
    print("        2 = Faible variance")
    print("\n    Distribution:")
    for qc, count in qc_counts.items():
        pct = count / len(df) * 100
        print(f"        QC Flag {qc}: {count:8,} ({pct:5.2f}%)")

# ============================================================================
# ÉTAPE 6: ANALYSE TEMPORELLE
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 6: ANALYSE TEMPORELLE")
print("="*80)

# Années de plantation
if 'planting_year' in df.columns:
    print("\n6.1 Distribution des années de plantation:")
    print("-" * 80)
    print(f"    Année minimale: {df['planting_year'].min()}")
    print(f"    Année maximale: {df['planting_year'].max()}")
    print(f"    Étendue: {df['planting_year'].max() - df['planting_year'].min()} ans")
    print(f"    Moyenne: {df['planting_year'].mean():.1f}")
    print(f"    Médiane: {df['planting_year'].median():.0f}")
    
    print("\n    Enregistrements par décennie:")
    df_temp = df.dropna(subset=['planting_year'])
    df_temp['decade'] = (df_temp['planting_year'] // 10) * 10
    decade_counts = df_temp['decade'].value_counts().sort_index()
    for decade, count in decade_counts.items():
        pct = count / len(df_temp) * 100
        print(f"        {int(decade)}s: {count:8,} ({pct:5.2f}%)")
    
    print("\n    Enregistrements par année (5 premières et 5 dernières):")
    year_counts = df['planting_year'].value_counts().sort_index()
    print("    Premières années:")
    for year, count in year_counts.head(5).items():
        print(f"        {int(year)}: {count:8,}")
    print("    ...")
    print("    Dernières années:")
    for year, count in year_counts.tail(5).items():
        print(f"        {int(year)}: {count:8,}")

# Années de récolte
if 'harvest_year' in df.columns:
    print("\n6.2 Distribution des années de récolte:")
    print("-" * 80)
    print(f"    Année minimale: {df['harvest_year'].min()}")
    print(f"    Année maximale: {df['harvest_year'].max()}")
    print(f"    Étendue: {df['harvest_year'].max() - df['harvest_year'].min()} ans")
    print(f"    Moyenne: {df['harvest_year'].mean():.1f}")
    print(f"    Médiane: {df['harvest_year'].median():.0f}")

# Mois de plantation
if 'planting_month' in df.columns:
    print("\n6.3 Distribution des mois de plantation:")
    print("-" * 80)
    month_counts = df['planting_month'].value_counts().sort_index()
    mois_noms = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 
                 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc']
    for month, count in month_counts.items():
        if not pd.isna(month):
            pct = count / df['planting_month'].notna().sum() * 100
            month_name = mois_noms[int(month)-1] if 1 <= month <= 12 else str(month)
            print(f"        {month_name} ({int(month):2d}): {count:8,} ({pct:5.2f}%)")

# Mois de récolte
if 'harvest_month' in df.columns:
    print("\n6.4 Distribution des mois de récolte:")
    print("-" * 80)
    month_counts = df['harvest_month'].value_counts().sort_index()
    for month, count in month_counts.items():
        if not pd.isna(month):
            pct = count / df['harvest_month'].notna().sum() * 100
            month_name = mois_noms[int(month)-1] if 1 <= month <= 12 else str(month)
            print(f"        {month_name} ({int(month):2d}): {count:8,} ({pct:5.2f}%)")

# ============================================================================
# ÉTAPE 7: ANALYSES CROISÉES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 7: ANALYSES CROISÉES")
print("="*80)

# Production moyenne par pays
if 'country' in df.columns and 'production' in df.columns:
    print("\n7.1 Production moyenne par pays (Top 15):")
    print("-" * 80)
    prod_by_country = df.groupby('country')['production'].agg(['mean', 'median', 'sum', 'count'])
    prod_by_country = prod_by_country.sort_values('sum', ascending=False).head(15)
    prod_by_country.columns = ['Moyenne_t', 'Médiane_t', 'Total_t', 'Nb_records']
    print(prod_by_country.round(2))

# Rendement moyen par culture
if 'product' in df.columns and 'yield' in df.columns:
    print("\n7.2 Rendement moyen par culture (Top 20):")
    print("-" * 80)
    yield_by_product = df.groupby('product')['yield'].agg(['mean', 'median', 'std', 'count'])
    yield_by_product = yield_by_product.sort_values('mean', ascending=False).head(20)
    yield_by_product.columns = ['Moyenne_t/ha', 'Médiane_t/ha', 'Écart_type', 'Nb_records']
    print(yield_by_product.round(3))

# Superficie totale par pays
if 'country' in df.columns and 'area' in df.columns:
    print("\n7.3 Superficie totale cultivée par pays (Top 15):")
    print("-" * 80)
    area_by_country = df.groupby('country')['area'].agg(['sum', 'mean', 'count'])
    area_by_country = area_by_country.sort_values('sum', ascending=False).head(15)
    area_by_country.columns = ['Total_ha', 'Moyenne_ha', 'Nb_records']
    print(area_by_country.round(2))

# Évolution temporelle de la production totale
if 'harvest_year' in df.columns and 'production' in df.columns:
    print("\n7.4 Évolution de la production totale par année:")
    print("-" * 80)
    prod_by_year = df.groupby('harvest_year')['production'].agg(['sum', 'mean', 'count'])
    prod_by_year.columns = ['Total_t', 'Moyenne_t', 'Nb_records']
    print("    10 premières années:")
    print(prod_by_year.head(10).round(2))
    print("\n    10 dernières années:")
    print(prod_by_year.tail(10).round(2))

# Cultures principales par pays
if 'country' in df.columns and 'product' in df.columns:
    print("\n7.5 Top 3 cultures par pays (par nombre d'enregistrements):")
    print("-" * 80)
    for country in df['country'].value_counts().head(10).index:
        print(f"\n    {country}:")
        country_data = df[df['country'] == country]
        top_products = country_data['product'].value_counts().head(3)
        for i, (product, count) in enumerate(top_products.items(), 1):
            pct = count / len(country_data) * 100
            print(f"        {i}. {product:30s}: {count:6,} ({pct:5.2f}%)")

# Système de production vs rendement
if 'crop_production_system' in df.columns and 'yield' in df.columns:
    print("\n7.6 Rendement moyen par système de production:")
    print("-" * 80)
    yield_by_system = df.groupby('crop_production_system')['yield'].agg(['mean', 'median', 'std', 'count'])
    yield_by_system.columns = ['Moyenne_t/ha', 'Médiane_t/ha', 'Écart_type', 'Nb_records']
    print(yield_by_system.round(3))

# ============================================================================
# ÉTAPE 8: ANALYSE DES CÉRÉALES PRINCIPALES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 8: ANALYSE DES CÉRÉALES PRINCIPALES D'AFRIQUE SUBSAHARIENNE")
print("="*80)

if 'product' in df.columns:
    # Identifier les céréales (variations de noms possibles)
    cereals_map = {
        'wheat': ['wheat', 'Wheat', 'blé', 'Blé'],
        'maize': ['maize', 'Maize', 'corn', 'Corn', 'maïs', 'Maïs'],
        'rice': ['rice', 'Rice', 'riz', 'Riz'],
        'sorghum': ['sorghum', 'Sorghum', 'sorgho', 'Sorgho'],
        'barley': ['barley', 'Barley', 'orge', 'Orge'],
        'millet': ['millet', 'Millet', 'mil', 'Mil'],
        'fonio': ['fonio', 'Fonio']
    }
    
    # Créer une nouvelle colonne pour les céréales normalisées
    df['cereal_type'] = None
    for cereal_std, variations in cereals_map.items():
        mask = df['product'].isin(variations)
        df.loc[mask, 'cereal_type'] = cereal_std
    
    cereals_df = df[df['cereal_type'].notna()].copy()
    
    if len(cereals_df) > 0:
        print(f"\n8.1 Vue d'ensemble des céréales principales:")
        print(f"    Total enregistrements de céréales: {len(cereals_df):,}")
        print(f"    Pourcentage du dataset: {len(cereals_df)/len(df)*100:.2f}%")
        
        print("\n8.2 Distribution par type de céréale:")
        print("-" * 80)
        cereal_counts = cereals_df['cereal_type'].value_counts()
        for cereal, count in cereal_counts.items():
            pct = count / len(cereals_df) * 100
            print(f"    {cereal.capitalize():15s}: {count:8,} ({pct:5.2f}%)")
        
        if 'production' in df.columns:
            print("\n8.3 Production totale par céréale:")
            print("-" * 80)
            prod_cereals = cereals_df.groupby('cereal_type')['production'].sum().sort_values(ascending=False)
            for cereal, prod in prod_cereals.items():
                print(f"    {cereal.capitalize():15s}: {prod:15,.0f} tonnes")
        
        if 'yield' in df.columns:
            print("\n8.4 Rendement moyen par céréale:")
            print("-" * 80)
            yield_cereals = cereals_df.groupby('cereal_type')['yield'].agg(['mean', 'median', 'std'])
            yield_cereals.columns = ['Moyenne_t/ha', 'Médiane_t/ha', 'Écart_type']
            print(yield_cereals.round(3))
        
        if 'area' in df.columns:
            print("\n8.5 Superficie totale par céréale:")
            print("-" * 80)
            area_cereals = cereals_df.groupby('cereal_type')['area'].sum().sort_values(ascending=False)
            for cereal, area in area_cereals.items():
                print(f"    {cereal.capitalize():15s}: {area:15,.0f} hectares")
        
        if 'country' in df.columns:
            print("\n8.6 Principaux pays producteurs par céréale:")
            print("-" * 80)
            for cereal in cereal_counts.head(5).index:
                print(f"\n    {cereal.upper()}:")
                cereal_data = cereals_df[cereals_df['cereal_type'] == cereal]
                top_countries = cereal_data['country'].value_counts().head(5)
                for i, (country, count) in enumerate(top_countries.items(), 1):
                    print(f"        {i}. {country:25s}: {count:6,} enregistrements")

# ============================================================================
# ÉTAPE 9: ANALYSE DE LA QUALITÉ DES DONNÉES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 9: ANALYSE DE LA QUALITÉ DES DONNÉES")
print("="*80)

# Valeurs aberrantes
if 'qc_flag' in df.columns:
    print("\n9.1 Répartition des problèmes de qualité:")
    print("-" * 80)
    qc_stats = df['qc_flag'].value_counts()
    total = len(df)
    print(f"    Données valides (QC=0):        {qc_stats.get(0, 0):8,} ({qc_stats.get(0, 0)/total*100:5.2f}%)")
    print(f"    Valeurs aberrantes (QC=1):     {qc_stats.get(1, 0):8,} ({qc_stats.get(1, 0)/total*100:5.2f}%)")
    print(f"    Faible variance (QC=2):        {qc_stats.get(2, 0):8,} ({qc_stats.get(2, 0)/total*100:5.2f}%)")

# Détection de valeurs extrêmes
if 'yield' in df.columns:
    print("\n9.2 Détection de rendements extrêmes:")
    print("-" * 80)
    Q1 = df['yield'].quantile(0.25)
    Q3 = df['yield'].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 3 * IQR
    upper_bound = Q3 + 3 * IQR
    
    extreme_low = (df['yield'] < lower_bound).sum()
    extreme_high = (df['yield'] > upper_bound).sum()
    
    print(f"    Seuil inférieur (Q1 - 3*IQR): {lower_bound:.2f} t/ha")
    print(f"    Seuil supérieur (Q3 + 3*IQR): {upper_bound:.2f} t/ha")
    print(f"    Rendements extrêmement bas:   {extreme_low:8,} ({extreme_low/len(df)*100:.2f}%)")
    print(f"    Rendements extrêmement élevés: {extreme_high:8,} ({extreme_high/len(df)*100:.2f}%)")

# Cohérence area * yield = production
if all(col in df.columns for col in ['area', 'yield', 'production']):
    print("\n9.3 Vérification de cohérence (area × yield ≈ production):")
    print("-" * 80)
    df_check = df[df[['area', 'yield', 'production']].notna().all(axis=1)].copy()
    df_check['production_calc'] = df_check['area'] * df_check['yield']
    df_check['diff'] = abs(df_check['production'] - df_check['production_calc'])
    df_check['diff_pct'] = (df_check['diff'] / df_check['production'] * 100)
    
    coherent = (df_check['diff_pct'] < 5).sum()
    total_check = len(df_check)
    
    print(f"    Enregistrements vérifiables:      {total_check:8,}")
    print(f"    Cohérents (<5% différence):       {coherent:8,} ({coherent/total_check*100:.2f}%)")
    print(f"    Différence moyenne:               {df_check['diff_pct'].mean():.2f}%")
    print(f"    Différence médiane:               {df_check['diff_pct'].median():.2f}%")

# ============================================================================
# ÉTAPE 10: ANALYSES AVANCÉES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 10: ANALYSES AVANCÉES")
print("="*80)

# Tendances temporelles
if 'harvest_year' in df.columns and 'yield' in df.columns:
    print("\n10.1 Évolution du rendement moyen par décennie:")
    print("-" * 80)
    df_temp = df[df['harvest_year'].notna() & df['yield'].notna()].copy()
    df_temp['decade'] = (df_temp['harvest_year'] // 10) * 10
    decade_yield = df_temp.groupby('decade')['yield'].agg(['mean', 'median', 'count'])
    decade_yield.columns = ['Rendement_moyen_t/ha', 'Rendement_médian_t/ha', 'Nb_records']
    print(decade_yield.round(3))
    
    # Taux de croissance
    if len(decade_yield) > 1:
        print("\n    Taux de croissance du rendement moyen:")
        decades = sorted(df_temp['decade'].unique())
        for i in range(1, len(decades)):
            prev_decade = decades[i-1]
            curr_decade = decades[i]
            prev_yield = df_temp[df_temp['decade'] == prev_decade]['yield'].mean()
            curr_yield = df_temp[df_temp['decade'] == curr_decade]['yield'].mean()
            growth = ((curr_yield - prev_yield) / prev_yield) * 100
            print(f"        {int(prev_decade)}s → {int(curr_decade)}s: {growth:+.2f}%")

# Écart de rendement (yield gap)
if 'yield' in df.columns and 'product' in df.columns:
    print("\n10.2 Écart de rendement par culture (yield gap):")
    print("-" * 80)
    print("    (Différence entre rendement max et moyen)")
    
    for product in df['product'].value_counts().head(10).index:
        product_data = df[df['product'] == product]['yield'].dropna()
        if len(product_data) > 0:
            mean_yield = product_data.mean()
            max_yield = product_data.quantile(0.90)  # 90e percentile
            gap = max_yield - mean_yield
            gap_pct = (gap / mean_yield) * 100
            print(f"    {product:30s}: Gap = {gap:6.2f} t/ha ({gap_pct:5.1f}%)")

# Variabilité interannuelle
if 'harvest_year' in df.columns and 'production' in df.columns and 'country' in df.columns:
    print("\n10.3 Variabilité interannuelle de la production (CV%):")
    print("-" * 80)
    print("    (Coefficient de variation pour les pays avec >20 ans de données)")
    
    for country in df['country'].value_counts().head(10).index:
        country_annual = df[df['country'] == country].groupby('harvest_year')['production'].sum()
        if len(country_annual) >= 20:
            cv = (country_annual.std() / country_annual.mean()) * 100
            print(f"    {country:30s}: CV = {cv:6.2f}%")

# Intensification agricole
if all(col in df.columns for col in ['harvest_year', 'production', 'area']):
    print("\n10.4 Indice d'intensification agricole:")
    print("-" * 80)
    print("    (Production/Superficie sur les périodes 1980-1999 vs 2000-2022)")
    
    df_early = df[(df['harvest_year'] >= 1980) & (df['harvest_year'] < 2000)]
    df_recent = df[(df['harvest_year'] >= 2000) & (df['harvest_year'] <= 2022)]
    
    if len(df_early) > 0 and len(df_recent) > 0:
        early_intensity = df_early['production'].sum() / df_early['area'].sum()
        recent_intensity = df_recent['production'].sum() / df_recent['area'].sum()
        change = ((recent_intensity - early_intensity) / early_intensity) * 100
        
        print(f"    Intensité 1980-1999:  {early_intensity:.3f} t/ha")
        print(f"    Intensité 2000-2022:  {recent_intensity:.3f} t/ha")
        print(f"    Changement:           {change:+.2f}%")

# ============================================================================
# ÉTAPE 11: CORRÉLATIONS
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 11: ANALYSE DES CORRÉLATIONS")
print("="*80)

numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
if len(numeric_cols) > 1:
    print("\n11.1 Matrice de corrélation (variables numériques):")
    print("-" * 80)
    corr_matrix = df[numeric_cols].corr()
    print(corr_matrix.round(3))
    
    print("\n11.2 Corrélations les plus fortes (|r| > 0.5):")
    print("-" * 80)
    # Extraire les paires de corrélations fortes
    strong_corr = []
    for i in range(len(corr_matrix.columns)):
        for j in range(i+1, len(corr_matrix.columns)):
            corr_val = corr_matrix.iloc[i, j]
            if abs(corr_val) > 0.5:
                strong_corr.append((
                    corr_matrix.columns[i],
                    corr_matrix.columns[j],
                    corr_val
                ))
    
    if strong_corr:
        for var1, var2, corr in sorted(strong_corr, key=lambda x: abs(x[2]), reverse=True):
            print(f"    {var1:20s} ↔ {var2:20s}: r = {corr:+.3f}")
    else:
        print("    Aucune corrélation forte détectée (|r| > 0.5)")

# ============================================================================
# ÉTAPE 12: SYNTHÈSE GÉOGRAPHIQUE
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 12: SYNTHÈSE GÉOGRAPHIQUE")
print("="*80)

if gdf is not None:
    print("\n12.1 Informations sur les données géographiques:")
    print("-" * 80)
    print(f"    Nombre d'entités:     {len(gdf):,}")
    print(f"    Système de référence: {gdf.crs}")
    print(f"    Colonnes disponibles: {list(gdf.columns)}")
    print(f"    Types de géométries:  {gdf.geometry.type.value_counts().to_dict()}")
    
    if 'fnid' in gdf.columns and 'fnid' in df.columns:
        print("\n12.2 Jointure données / géographie:")
        print("-" * 80)
        common_fnids = set(df['fnid'].dropna().unique()) & set(gdf['fnid'].dropna().unique())
        print(f"    FNID uniques dans CSV:      {df['fnid'].nunique():,}")
        print(f"    FNID uniques dans GeoPackage: {gdf['fnid'].nunique():,}")
        print(f"    FNID en commun:             {len(common_fnids):,}")
        
        df_only = df['fnid'].nunique() - len(common_fnids)
        gdf_only = gdf['fnid'].nunique() - len(common_fnids)
        print(f"    FNID uniquement dans CSV:   {df_only:,}")
        print(f"    FNID uniquement dans GeoPackage: {gdf_only:,}")

# ============================================================================
# ÉTAPE 13: RÉSUMÉ EXÉCUTIF
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 13: RÉSUMÉ EXÉCUTIF")
print("="*80)

print(f"""
HARVESTSTAT AFRICA - RÉSUMÉ DES STATISTIQUES CLÉS
{'='*80}

1. COUVERTURE DU DATASET
   • Nombre total d'enregistrements:  {len(df):,}
   • Période couverte:                {df['harvest_year'].min():.0f} - {df['harvest_year'].max():.0f}
   • Nombre de pays:                  {df['country'].nunique() if 'country' in df.columns else 'N/A'}
   • Nombre de cultures:              {df['product'].nunique() if 'product' in df.columns else 'N/A'}
   • Unités admin niveau 1:           {df['admin_1'].nunique() if 'admin_1' in df.columns else 'N/A'}
   • Unités admin niveau 2:           {df['admin_2'].nunique() if 'admin_2' in df.columns else 'N/A'}

2. STATISTIQUES AGRICOLES GLOBALES
   • Production totale:               {df['production'].sum():,.0f} tonnes
   • Superficie totale:               {df['area'].sum():,.0f} hectares
   • Rendement moyen:                 {df['yield'].mean():.2f} t/ha
   • Rendement médian:                {df['yield'].median():.2f} t/ha

3. QUALITÉ DES DONNÉES
   • Données valides (QC=0):          {(df['qc_flag']==0).sum() if 'qc_flag' in df.columns else 'N/A':,} ({(df['qc_flag']==0).sum()/len(df)*100 if 'qc_flag' in df.columns else 0:.1f}%)
   • Valeurs aberrantes (QC=1):       {(df['qc_flag']==1).sum() if 'qc_flag' in df.columns else 'N/A':,} ({(df['qc_flag']==1).sum()/len(df)*100 if 'qc_flag' in df.columns else 0:.1f}%)
   • Faible variance (QC=2):          {(df['qc_flag']==2).sum() if 'qc_flag' in df.columns else 'N/A':,} ({(df['qc_flag']==2).sum()/len(df)*100 if 'qc_flag' in df.columns else 0:.1f}%)

4. TOP 5 PAYS (par nombre d'enregistrements)
{chr(10).join([f"   {i+1}. {country:30s} : {count:,}" for i, (country, count) in enumerate(df['country'].value_counts().head(5).items())]) if 'country' in df.columns else '   N/A'}

5. TOP 5 CULTURES (par nombre d'enregistrements)
{chr(10).join([f"   {i+1}. {product:30s} : {count:,}" for i, (product, count) in enumerate(df['product'].value_counts().head(5).items())]) if 'product' in df.columns else '   N/A'}

6. CÉRÉALES PRINCIPALES
{chr(10).join([f"   • {cereal.capitalize():15s} : {count:,} enregistrements" for cereal, count in cereals_df['cereal_type'].value_counts().items()]) if len(cereals_df) > 0 else '   Données non disponibles'}

7. COMPLÉTUDE DES DONNÉES
   • Enregistrements complets:        {df.notna().all(axis=1).sum():,} ({df.notna().all(axis=1).sum()/len(df)*100:.2f}%)
   • Avec au moins 1 valeur manquante: {df.isna().any(axis=1).sum():,} ({df.isna().any(axis=1).sum()/len(df)*100:.2f}%)

{'='*80}
""")

# ============================================================================
# ÉTAPE 14: RECOMMANDATIONS POUR ANALYSES FUTURES
# ============================================================================
print("\n" + "="*80)
print("ÉTAPE 14: RECOMMANDATIONS POUR ANALYSES FUTURES")
print("="*80)

print("""
Sur la base de cette exploration exhaustive, voici les analyses complémentaires
recommandées:

1. ANALYSES SPATIALES
   • Cartographie de la production par région
   • Identification de clusters de productivité
   • Analyse de l'autocorrélation spatiale
   • Zones de rendement optimal vs sous-optimal

2. MODÉLISATION
   • Modèles de prédiction de rendement
   • Analyse de l'impact climatique (avec données météo)
   • Modèles de séries temporelles (ARIMA, Prophet)
   • Machine Learning pour classification des systèmes productifs

3. ANALYSES ÉCONOMIQUES
   • Analyse coût-bénéfice par système de production
   • Évaluation de la sécurité alimentaire régionale
   • Impact des politiques agricoles

4. CHANGEMENT CLIMATIQUE
   • Corrélation rendements / indices climatiques
   • Tendances de productivité face au réchauffement
   • Vulnérabilité des différentes cultures

5. QUALITÉ DES DONNÉES
   • Imputation des valeurs manquantes
   • Validation croisée avec autres sources
   • Harmonisation des unités administratives

6. VISUALISATIONS
   • Cartes interactives (Folium, Plotly)
   • Tableaux de bord (Dash, Streamlit)
   • Animations temporelles
   • Graphiques de comparaison multi-pays
""")

print("\n" + "="*80)
print("FIN DE L'ANALYSE")
print("="*80)
print(f"\nRapport généré le: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Dataset analysé: HarvestStat Africa v1.0")
print(f"Nombre total d'enregistrements traités: {len(df):,}")
print("="*80)

# Sauvegarder un résumé
summary_file = Path('/home/claude/analyse_summary.txt')
with open(summary_file, 'w', encoding='utf-8') as f:
    f.write("="*80 + "\n")
    f.write("HARVESTSTAT AFRICA - RÉSUMÉ DE L'ANALYSE\n")
    f.write("="*80 + "\n\n")
    f.write(f"Date d'analyse: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write(f"Enregistrements: {len(df):,}\n")
    f.write(f"Période: {df['harvest_year'].min():.0f} - {df['harvest_year'].max():.0f}\n")
    f.write(f"Pays: {df['country'].nunique() if 'country' in df.columns else 'N/A'}\n")
    f.write(f"Cultures: {df['product'].nunique() if 'product' in df.columns else 'N/A'}\n")
    f.write("\nFichier de résumé sauvegardé.\n")

print(f"\n✓ Résumé sauvegardé dans: {summary_file}")