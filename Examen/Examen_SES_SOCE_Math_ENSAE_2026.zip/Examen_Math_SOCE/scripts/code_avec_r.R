# ============================================================
# EXAMEN DE SES 
# ============================================================
# ============================================================
# PARTIE 1 : CONFIGURATION ET CHARGEMENT DES DONNÉES
# ============================================================

cat(paste(rep("=", 90), collapse = ""), "\n")
cat("PARTIE 1 : CONFIGURATION ET CHARGEMENT DES DONNÉES\n")
cat(paste(rep("=", 90), collapse = ""), "\n\n")

# ------------------------------------------------------------
# 1.1 : Chargement des packages
# ------------------------------------------------------------

cat("1.1 Chargement des packages R...\n")

packages_requis <- c(
  "sf",              # Données vectorielles
  "terra",           # Données raster
  "tidyverse",       # Manipulation de données
  "exactextractr",   # Statistiques zonales
  "ggplot2",         # Graphiques
  "gridExtra",       # Arrangement de graphiques
  "viridis",         # Palettes de couleurs
  "scales",          # Formatage
  "readr"
)

for (pkg in packages_requis) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    cat("  Installation de", pkg, "...\n")
    install.packages(pkg)
    library(pkg, character.only = TRUE)
  }
}

cat("  ✓ Tous les packages sont chargés\n\n")

# ------------------------------------------------------------
# 1.2 : définition des chemins
# ------------------------------------------------------------
 
gpkg_path <- "C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE/data/hvstat_africa_boundary_v1.0.gpkg"
csv_path <- "C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE/data/hvstat_africa_boundary_v1.0"
out_dir  <- "C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE/outputs/"

# Créer le dossier outputs s'il n'existe pas
if(!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# ==============================================================================
# PARTIE 2.1 : INSPECTION 
# ==============================================================================

path <- paste0("C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE/data/",
               "hvstat_africa_boundary_v1.0.csv")
read_csv(path)
csv <- read_csv(csv_path,(header = FALSE))

# Lecture du geopackage (quiet = TRUE évite les messages de sf)
gpkg <- st_read(gpkg_path, quiet = TRUE)

# Afficher un aperçu des données
cat("--- Aperçu des données (première entité) ---\n")
print(gpkg[1, ])

# Vérifier le système de coordonnées (CRS)
cat("\n--- Système de projection ---\n")
crs_info <- st_crs(gpkg)
print(crs_info)

# Afficher l'emprise géographique (bounding box)
cat("\n--- Emprise géographique (bbox) ---\n")
bbox <- st_bbox(gpkg)
print(bbox)

# Statistiques de base
cat("\n--- Résumé ---\n")
cat("Nombre d'entités (régions/polygones):", nrow(gpkg), "\n")
cat("Nombre de colonnes (attributs):", ncol(gpkg), "\n")
cat("Nom des colonnes:", paste(names(gpkg), collapse = ", "), "\n")

# FNID est l'identifiant des observations dans la base geopackage.
# ADMIN1 représente les régions
# ADMIN2 représente les départments.

# Area (Surface/Superficie) : Mesure l'étendue géographique consacrée à une culture spécifique, généralement exprimée en hectares (\(ha\)) ou en acres. Elle représente l'input foncier.
# Production (Quantité récoltée) : Représente le volume physique total (ou poids) de la récolte obtenu sur la surface donnée, exprimé en tonnes (\(t\)) ou kilogrammes (\(kg\)). C'est le résultat absolu.
# Yield (Rendement) : Mesure l'efficacité de la production, définie comme la quantité récoltée par unité de surface (\(t/ha\) ou \(kg/m^{2}\)). Il reflète l'intensité technique ou la productivité de la terre.

# ==============================================================================
# PARTIE 2.2 : INSPECTION DES CSV
# ==============================================================================








