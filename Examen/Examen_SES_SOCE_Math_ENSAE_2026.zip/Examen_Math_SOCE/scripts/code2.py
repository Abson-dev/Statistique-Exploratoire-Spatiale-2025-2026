#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANALYSE DÉTAILLÉE PAR PAYS - HARVESTSTAT AFRICA
================================================
Analyse exhaustive d'un pays spécifique avec cartographie complète

Structure attendue:
    projet/
    ├── data/
    │   ├── hvstat_africa_data_v1.0.csv
    │   └── hvstat_africa_boundary_v1.0.gpkg
    ├── outputs/
    │   └── [pays]/  (sera créé automatiquement)
    └── scripts/
        └── analyse_pays.py (ce fichier)

Auteur: Claude
Date: 2026-02-06
"""

import pandas as pd
import geopandas as gpd
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import sys
import contextily as ctx

warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION DES CHEMINS
# ============================================================================

PROJECT_DIR = Path(r"C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE")
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "outputs"
SCRIPTS_DIR = PROJECT_DIR / "scripts"

# Vérification et création automatique des dossiers
for folder_name, path in [('data', DATA_DIR), ('outputs', OUTPUT_DIR), ('scripts', SCRIPTS_DIR)]:
    if not path.exists():
        print(f"⚠️  ATTENTION: Le dossier '{folder_name}' n'existe pas à {path}")
        print(f"   Création du dossier...")
        path.mkdir(parents=True, exist_ok=True)

print("="*90)
print("ANALYSE DÉTAILLÉE PAR PAYS - HARVESTSTAT AFRICA")
print("="*90)
print(f"\n📁 Structure du projet:")
print(f"   Racine:   {PROJECT_DIR}")
print(f"   Données:  {DATA_DIR}")
print(f"   Sorties:  {OUTPUT_DIR}")
print(f"   Scripts:  {SCRIPTS_DIR}")

# ============================================================================
# CONFIGURATION GRAPHIQUE
# ============================================================================

plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("Set2")
plt.rcParams['figure.figsize'] = (16, 10)
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['legend.fontsize'] = 9
plt.rcParams['figure.titlesize'] = 16

# Couleurs personnalisées pour les cartes
COLORS = {
    'production': ['#ffffcc','#ffeda0','#fed976','#feb24c','#fd8d3c','#fc4e2a','#e31a1c','#bd0026','#800026'],
    'rendement': ['#f7fbff','#deebf7','#c6dbef','#9ecae1','#6baed6','#4292c6','#2171b5','#08519c','#08306b'],
    'superficie': ['#f7fcf5','#e5f5e0','#c7e9c0','#a1d99b','#74c476','#41ab5d','#238b45','#006d2c','#00441b'],
    'qualite': ['#1a9850','#91cf60','#d9ef8b','#fee08b','#fc8d59','#d73027']
}

# ============================================================================
# ÉTAPE 1: CHARGEMENT DES DONNÉES
# ============================================================================

print("\n" + "="*90)
print("ÉTAPE 1: CHARGEMENT DES DONNÉES")
print("="*90)

csv_file = DATA_DIR / 'hvstat_africa_data_v1.0.csv'
gpkg_file = DATA_DIR / 'hvstat_africa_boundary_v1.0.gpkg'

# Vérification de l'existence des fichiers
if not csv_file.exists():
    print(f"\n❌ ERREUR: Fichier CSV non trouvé: {csv_file}")
    print(f"   Veuillez placer 'hvstat_africa_data_v1.0.csv' dans le dossier 'data/'")
    sys.exit(1)

if not gpkg_file.exists():
    print(f"\n❌ ERREUR: Fichier GeoPackage non trouvé: {gpkg_file}")
    print(f"   Veuillez placer 'hvstat_africa_boundary_v1.0.gpkg' dans le dossier 'data/'")
    sys.exit(1)

# Chargement CSV
print(f"\n1.1 Chargement du fichier CSV...")
df_global = pd.read_csv(csv_file, low_memory=False)
print(f"    ✅ Chargé avec succès : {len(df_global):,} enregistrements, {len(df_global.columns)} colonnes")

# Chargement GeoPackage
print(f"\n1.2 Chargement du fichier GeoPackage...")
gdf_global = gpd.read_file(gpkg_file)
print(f"    ✅ Chargé avec succès : {len(gdf_global):,} entités géographiques, CRS = {gdf_global.crs}")
