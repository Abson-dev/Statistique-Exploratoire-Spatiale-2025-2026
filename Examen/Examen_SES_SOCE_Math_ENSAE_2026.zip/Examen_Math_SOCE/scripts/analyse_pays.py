# -*- coding: utf-8 -*-
"""
ANALYSE DÉTAILLÉE PAR PAYS - HARVESTSTAT AFRICA
================================================
Analyse exhaustive d'un pays spécifique avec cartographie complète

Structure attendue:
    projet/
    ├── data/
    │   ├── hvstat_africa_data_v1.0.csv
    │   └── hvstat_africa_boundary_v1.0.gpkg
    ├── outputs/
    │   └── [pays]/  (sera créé automatiquement)
    └── scripts/
        └── analyse_pays.py (ce fichier)

Auteur: Math SOCE
Date: 2026-02-06
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gpd
from pathlib import Path
import warnings
import sys
import random
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Rectangle
import contextily as ctx

warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION DES CHEMINS
# ============================================================================

# Racine du projet (Windows) – utilise raw string pour éviter les problèmes de backslash
PROJECT_DIR = Path(r"C:/Users/Easy Services Pro/OneDrive/Bureau/ENSAE_ISEP3/Semestre1/Statistique/Stat E. spaciale/Examen_Math_SOCE")
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "outputs"
SCRIPTS_DIR = PROJECT_DIR / "scripts"

# Vérifier / créer les dossiers
for folder_name, path in [('data', DATA_DIR), ('outputs', OUTPUT_DIR), ('scripts', SCRIPTS_DIR)]:
    if not path.exists():
        print(f"⚠️  ATTENTION: Le dossier '{folder_name}' n'existe pas à {path}")
        print(f"   Création du dossier...")
        path.mkdir(parents=True, exist_ok=True)

print("="*90)
print("ANALYSE DÉTAILLÉE PAR PAYS - HARVESTSTAT AFRICA")
print("="*90)
print(f"\n📁 Structure du projet:")
print(f"   Racine:   {PROJECT_DIR}")
print(f"   Données:  {DATA_DIR}")
print(f"   Sorties:  {OUTPUT_DIR}")
print(f"   Scripts:  {SCRIPTS_DIR}")

# ============================================================================
# CONFIGURATION GRAPHIQUE
# ============================================================================

plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("Set2")
plt.rcParams['figure.figsize'] = (16, 10)
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['legend.fontsize'] = 9
plt.rcParams['figure.titlesize'] = 16

# Couleurs personnalisées pour les cartes
COLORS = {
    'production': ['#ffffcc', '#ffeda0', '#fed976', '#feb24c', '#fd8d3c', '#fc4e2a', '#e31a1c', '#bd0026', '#800026'],
    'rendement': ['#f7fbff', '#deebf7', '#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#08519c', '#08306b'],
    'superficie': ['#f7fcf5', '#e5f5e0', '#c7e9c0', '#a1d99b', '#74c476', '#41ab5d', '#238b45', '#006d2c', '#00441b'],
    'qualite': ['#1a9850', '#91cf60', '#d9ef8b', '#fee08b', '#fc8d59', '#d73027']
}

# ============================================================================
# ÉTAPE 1: CHARGEMENT DES DONNÉES
# ============================================================================

print("\n" + "="*90)
print("ÉTAPE 1: CHARGEMENT DES DONNÉES")
print("="*90)

# Fichiers de données
csv_file = DATA_DIR / 'hvstat_africa_data_v1.0'
gpkg_file = DATA_DIR / 'hvstat_africa_boundary_v1.0.gpkg'

# Vérification existence
if not csv_file.exists():
    print(f"\n❌ ERREUR: Fichier CSV non trouvé: {csv_file}")
    print(f"   Veuillez placer 'hvstat_africa_data_v1.0' dans le dossier 'data/'")
    sys.exit(1)

if not gpkg_file.exists():
    print(f"\n❌ ERREUR: Fichier GeoPackage non trouvé: {gpkg_file}")
    print(f"   Veuillez placer 'hvstat_africa_boundary_v1.0.gpkg' dans le dossier 'data/'")
    sys.exit(1)

# Chargement CSV
print(f"\n1.1 Chargement du fichier CSV...")
print(f"    📄 Fichier: {csv_file.name}")
df_global = pd.read_csv(csv_file, low_memory=False)
print(f"    ✅ Chargé avec succès")
print(f"    📊 Enregistrements: {len(df_global):,}")
print(f"    📋 Colonnes: {len(df_global.columns)}")

# Chargement GeoPackage
print(f"\n1.2 Chargement du fichier GeoPackage...")
print(f"    🗺️  Fichier: {gpkg_file.name}")
gdf_global = gpd.read_file(gpkg_file)
print(f"    ✅ Chargé avec succès")
print(f"    🌍 Entités géographiques: {len(gdf_global):,}")
print(f"    📐 Système de coordonnées: {gdf_global.crs}")

# ============================================================================
# ÉTAPE 2: SÉLECTION DU PAYS
# ============================================================================

print("\n" + "="*90)
print("ÉTAPE 2: SÉLECTION DU PAYS À ANALYSER")
print("="*90)

# Liste des pays disponibles
if 'country' not in df_global.columns:
    print("\n❌ ERREUR: Colonne 'country' non trouvée dans les données")
    sys.exit(1)

pays_disponibles = sorted(df_global['country'].dropna().unique())
print(f"\n2.1 Pays disponibles dans le dataset ({len(pays_disponibles)}):")
print("-" * 90)

# Afficher la liste avec nombre d'enregistrements
pays_stats = df_global['country'].value_counts().sort_index()
for i, pays in enumerate(pays_disponibles, 1):
    nb_records = pays_stats.get(pays, 0)
    print(f"   {i:2d}. {pays:35s} : {nb_records:6,} enregistrements")

# Sélection aléatoire
print(f"\n2.2 Sélection aléatoire d'un pays...")
PAYS_ANALYSE = random.choice(pays_disponibles)
print(f"    🎲 Pays sélectionné: {PAYS_ANALYSE}")

# Statistiques du pays sélectionné
nb_records_pays = (df_global['country'] == PAYS_ANALYSE).sum()
print(f"    📊 Nombre d'enregistrements: {nb_records_pays:,}")
print(f"    📈 Pourcentage du dataset global: {nb_records_pays/len(df_global)*100:.2f}%")

# Filtrer les données pour ce pays
df = df_global[df_global['country'] == PAYS_ANALYSE].copy()
print(f"\n    ✅ Données filtrées pour {PAYS_ANALYSE}")

# Filtrer les géométries
if 'country' in gdf_global.columns:
    gdf = gdf_global[gdf_global['country'] == PAYS_ANALYSE].copy()
elif 'COUNTRY' in gdf_global.columns:
    gdf = gdf_global[gdf_global['COUNTRY'] == PAYS_ANALYSE].copy()
else:
    # Essayer de joindre par fnid
    if 'fnid' in gdf_global.columns and 'fnid' in df.columns:
        fnids_pays = df['fnid'].unique()
        gdf = gdf_global[gdf_global['fnid'].isin(fnids_pays)].copy()
    else:
        print(f"    ⚠️  Impossible de filtrer les géométries pour {PAYS_ANALYSE}")
        gdf = gdf_global.copy()

print(f"    🗺️  Entités géographiques pour {PAYS_ANALYSE}: {len(gdf):,}")

# Créer le dossier de sortie pour ce pays
PAYS_OUTPUT_DIR = OUTPUT_DIR / PAYS_ANALYSE.replace(' ', '_')
PAYS_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
print(f"\n    📁 Dossier de sortie créé: {PAYS_OUTPUT_DIR}")

# ============================================================================
# ÉTAPE 3: APERÇU DES DONNÉES DU PAYS
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 3: APERÇU DES DONNÉES - {PAYS_ANALYSE}")
print("="*90)

print(f"\n3.1 Premières lignes du dataset:")
print("-" * 90)
print(df.head(15).to_string())

print(f"\n3.2 Informations sur les colonnes:")
print("-" * 90)
print(df.info())

print(f"\n3.3 Statistiques descriptives:")
print("-" * 90)
print(df.describe())

# ============================================================================
# ÉTAPE 4: ANALYSE DES UNITÉS ADMINISTRATIVES
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 4: ANALYSE DES UNITÉS ADMINISTRATIVES - {PAYS_ANALYSE}")
print("="*90)

# Admin niveau 1
if 'admin_1' in df.columns:
    admin1_unique = df['admin_1'].nunique()
    print(f"\n4.1 Unités administratives niveau 1 (Régions/États/Provinces):")
    print(f"    Nombre: {admin1_unique}")
    print("-" * 90)
    
    admin1_counts = df['admin_1'].value_counts()
    print(f"\n    Distribution des enregistrements par région:")
    for i, (admin, count) in enumerate(admin1_counts.items(), 1):
        pct = count / len(df) * 100
        print(f"    {i:2d}. {admin:45s} : {count:6,} ({pct:5.2f}%)")

# Admin niveau 2
if 'admin_2' in df.columns:
    admin2_unique = df['admin_2'].nunique()
    print(f"\n4.2 Unités administratives niveau 2 (Districts/Départements):")
    print(f"    Nombre: {admin2_unique}")
    print("-" * 90)
    
    admin2_counts = df['admin_2'].value_counts()
    print(f"\n    Top 20 districts par nombre d'enregistrements:")
    for i, (admin, count) in enumerate(admin2_counts.head(20).items(), 1):
        pct = count / len(df) * 100
        print(f"    {i:2d}. {admin:45s} : {count:6,} ({pct:5.2f}%)")

# ============================================================================
# ÉTAPE 5: ANALYSE DES CULTURES
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 5: ANALYSE DES CULTURES - {PAYS_ANALYSE}")
print("="*90)

if 'product' in df.columns:
    nb_cultures = df['product'].nunique()
    print(f"\n5.1 Nombre de cultures cultivées: {nb_cultures}")
    print("-" * 90)
    
    culture_counts = df['product'].value_counts()
    print(f"\n    Distribution par culture:")
    for i, (culture, count) in enumerate(culture_counts.items(), 1):
        pct = count / len(df) * 100
        print(f"    {i:2d}. {culture:45s} : {count:6,} ({pct:5.2f}%)")
    
    # Production totale par culture
    if 'production' in df.columns:
        print(f"\n5.2 Production totale par culture (tonnes):")
        print("-" * 90)
        prod_culture = df.groupby('product')['production'].sum().sort_values(ascending=False)
        for i, (culture, prod) in enumerate(prod_culture.items(), 1):
            pct = prod / prod_culture.sum() * 100
            print(f"    {i:2d}. {culture:45s} : {prod:15,.0f} t ({pct:5.2f}%)")
    
    # Superficie par culture
    if 'area' in df.columns:
        print(f"\n5.3 Superficie totale par culture (hectares):")
        print("-" * 90)
        area_culture = df.groupby('product')['area'].sum().sort_values(ascending=False)
        for i, (culture, area) in enumerate(area_culture.items(), 1):
            pct = area / area_culture.sum() * 100
            print(f"    {i:2d}. {culture:45s} : {area:15,.0f} ha ({pct:5.2f}%)")
    
    # Rendement moyen par culture
    if 'yield' in df.columns:
        print(f"\n5.4 Rendement moyen par culture (t/ha):")
        print("-" * 90)
        yield_culture = df.groupby('product')['yield'].mean().sort_values(ascending=False)
        for i, (culture, yld) in enumerate(yield_culture.items(), 1):
            print(f"    {i:2d}. {culture:45s} : {yld:8.2f} t/ha")

# ============================================================================
# ÉTAPE 6: ANALYSE TEMPORELLE
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 6: ANALYSE TEMPORELLE - {PAYS_ANALYSE}")
print("="*90)

if 'harvest_year' in df.columns:
    print(f"\n6.1 Couverture temporelle:")
    print("-" * 90)
    annee_min = df['harvest_year'].min()
    annee_max = df['harvest_year'].max()
    etendue = annee_max - annee_min
    print(f"    Première année: {annee_min:.0f}")
    print(f"    Dernière année: {annee_max:.0f}")
    print(f"    Étendue: {etendue:.0f} ans")
    print(f"    Année médiane: {df['harvest_year'].median():.0f}")
    
    # Distribution par année
    print(f"\n6.2 Enregistrements par année:")
    print("-" * 90)
    year_counts = df['harvest_year'].value_counts().sort_index()
    
    print("\n    Premières années (Top 10):")
    for year, count in year_counts.head(10).items():
        print(f"    {int(year):4d} : {count:6,} enregistrements")
    
    print("\n    Dernières années (Top 10):")
    for year, count in year_counts.tail(10).items():
        print(f"    {int(year):4d} : {count:6,} enregistrements")
    
    # Production par année
    if 'production' in df.columns:
        print(f"\n6.3 Production totale par année:")
        print("-" * 90)
        prod_year = df.groupby('harvest_year')['production'].sum().sort_index()
        
        print("\n    Premières années:")
        for year, prod in prod_year.head(10).items():
            print(f"    {int(year):4d} : {prod:15,.0f} tonnes")
        
        print("\n    Dernières années:")
        for year, prod in prod_year.tail(10).items():
            print(f"    {int(year):4d} : {prod:15,.0f} tonnes")
        
        # Taux de croissance
        if len(prod_year) > 1:
            croissance = ((prod_year.iloc[-1] - prod_year.iloc[0]) / prod_year.iloc[0]) * 100
            croissance_annuelle = croissance / len(prod_year)
            print(f"\n    Croissance totale: {croissance:+.2f}%")
            print(f"    Croissance annuelle moyenne: {croissance_annuelle:+.2f}%")
    
    # Rendement par année
    if 'yield' in df.columns:
        print(f"\n6.4 Rendement moyen par année:")
        print("-" * 90)
        yield_year = df.groupby('harvest_year')['yield'].mean().sort_index()
        
        print("\n    Premières années:")
        for year, yld in yield_year.head(10).items():
            print(f"    {int(year):4d} : {yld:8.2f} t/ha")
        
        print("\n    Dernières années:")
        for year, yld in yield_year.tail(10).items():
            print(f"    {int(year):4d} : {yld:8.2f} t/ha")
        
        # Tendance
        if len(yield_year) > 1:
            evolution = ((yield_year.iloc[-1] - yield_year.iloc[0]) / yield_year.iloc[0]) * 100
            evolution_annuelle = evolution / len(yield_year)
            print(f"\n    Évolution totale du rendement: {evolution:+.2f}%")
            print(f"    Évolution annuelle moyenne: {evolution_annuelle:+.2f}%")

# Analyse par décennie
if 'harvest_year' in df.columns:
    print(f"\n6.5 Analyse par décennie:")
    print("-" * 90)
    df_temp = df.dropna(subset=['harvest_year']).copy()
    df_temp['decade'] = (df_temp['harvest_year'] // 10) * 10
    
    decade_stats = df_temp.groupby('decade').agg({
        'production': 'sum',
        'area': 'sum',
        'yield': 'mean',
        'fnid': 'count'
    }).round(2)
    decade_stats.columns = ['Production_totale_t', 'Superficie_totale_ha', 'Rendement_moyen_t/ha', 'Nb_records']
    
    print(decade_stats)

# ============================================================================
# ÉTAPE 7: ANALYSE DES SYSTÈMES DE PRODUCTION
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 7: ANALYSE DES SYSTÈMES DE PRODUCTION - {PAYS_ANALYSE}")
print("="*90)

if 'crop_production_system' in df.columns:
    print(f"\n7.1 Types de systèmes de production:")
    print("-" * 90)
    
    system_counts = df['crop_production_system'].value_counts()
    for i, (system, count) in enumerate(system_counts.items(), 1):
        pct = count / len(df) * 100
        print(f"    {i}. {system:35s} : {count:6,} ({pct:5.2f}%)")
    
    # Rendement par système
    if 'yield' in df.columns:
        print(f"\n7.2 Rendement moyen par système de production:")
        print("-" * 90)
        yield_system = df.groupby('crop_production_system')['yield'].agg(['mean', 'median', 'std', 'count'])
        yield_system.columns = ['Moyenne_t/ha', 'Médiane_t/ha', 'Écart_type', 'Nb_records']
        print(yield_system.round(3))

# ============================================================================
# ÉTAPE 8: ANALYSE DE LA QUALITÉ DES DONNÉES
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 8: ANALYSE DE LA QUALITÉ DES DONNÉES - {PAYS_ANALYSE}")
print("="*90)

# QC Flags
if 'qc_flag' in df.columns:
    print(f"\n8.1 Distribution des indicateurs de qualité (QC Flag):")
    print("-" * 90)
    print("    Signification:")
    print("        0 = OK (données valides)")
    print("        1 = Valeur aberrante détectée")
    print("        2 = Faible variance")
    print()
    
    qc_counts = df['qc_flag'].value_counts().sort_index()
    for qc, count in qc_counts.items():
        pct = count / len(df) * 100
        print(f"    QC Flag {qc} : {count:6,} ({pct:5.2f}%)")

# Valeurs manquantes
print(f"\n8.2 Valeurs manquantes par colonne:")
print("-" * 90)
missing = df.isna().sum().sort_values(ascending=False)
missing_pct = (missing / len(df) * 100).round(2)
missing_df = pd.DataFrame({
    'Colonne': missing.index,
    'Valeurs_manquantes': missing.values,
    'Pourcentage': missing_pct.values
})
print(missing_df[missing_df['Valeurs_manquantes'] > 0].to_string(index=False))

# Cohérence des données
if all(col in df.columns for col in ['area', 'yield', 'production']):
    print(f"\n8.3 Vérification de cohérence (area × yield ≈ production):")
    print("-" * 90)
    df_check = df[df[['area', 'yield', 'production']].notna().all(axis=1)].copy()
    if len(df_check) > 0:
        df_check['production_calc'] = df_check['area'] * df_check['yield']
        df_check['diff_pct'] = abs(df_check['production'] - df_check['production_calc']) / df_check['production'] * 100
        
        coherent = (df_check['diff_pct'] < 5).sum()
        print(f"    Enregistrements vérifiables: {len(df_check):,}")
        print(f"    Cohérents (<5% diff): {coherent:,} ({coherent/len(df_check)*100:.2f}%)")
        print(f"    Différence moyenne: {df_check['diff_pct'].mean():.2f}%")
        print(f"    Différence médiane: {df_check['diff_pct'].median():.2f}%")

# ============================================================================
# ÉTAPE 9: ANALYSES SPATIALES
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 9: ANALYSES SPATIALES - {PAYS_ANALYSE}")
print("="*90)

print(f"\n9.1 Informations géographiques:")
print("-" * 90)
print(f"    Nombre d'entités géographiques: {len(gdf):,}")
print(f"    Système de coordonnées: {gdf.crs}")
print(f"    Colonnes disponibles: {list(gdf.columns)}")

# Calculer les limites géographiques
bounds = gdf.total_bounds
print(f"\n9.2 Limites géographiques du pays:")
print(f"    Longitude min: {bounds[0]:.4f}")
print(f"    Latitude min:  {bounds[1]:.4f}")
print(f"    Longitude max: {bounds[2]:.4f}")
print(f"    Latitude max:  {bounds[3]:.4f}")

# Jointure avec les données
if 'fnid' in gdf.columns and 'fnid' in df.columns:
    print(f"\n9.3 Jointure données / géométries:")
    print("-" * 90)
    
    # Agréger les données par fnid
    df_spatial = df.groupby('fnid').agg({
        'production': 'sum',
        'area': 'sum',
        'yield': 'mean',
        'harvest_year': 'count'
    }).reset_index()
    df_spatial.columns = ['fnid', 'production_totale', 'superficie_totale', 'rendement_moyen', 'nb_enregistrements']
    
    # Joindre
    gdf_enriched = gdf.merge(df_spatial, on='fnid', how='left')
    
    print(f"    Géométries avant jointure: {len(gdf):,}")
    print(f"    Géométries après jointure: {len(gdf_enriched):,}")
    print(f"    Géométries avec données: {gdf_enriched['production_totale'].notna().sum():,}")
    
    # Sauvegarder
    gdf_enriched.to_file(PAYS_OUTPUT_DIR / f'{PAYS_ANALYSE}_enriched.gpkg', driver='GPKG')
    print(f"\n    ✅ GeoPackage enrichi sauvegardé: {PAYS_ANALYSE}_enriched.gpkg")
else:
    gdf_enriched = gdf.copy()
    print(f"\n    ⚠️  Impossible de joindre (colonne fnid manquante)")

# ============================================================================
# ÉTAPE 10: CRÉATION DES VISUALISATIONS
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 10: CRÉATION DES VISUALISATIONS - {PAYS_ANALYSE}")
print("="*90)

print(f"\n10.1 Génération des graphiques...")

# ============================================================================
# FIGURE 1: Distributions des variables
# ============================================================================

print("\n    📊 Figure 1: Distribution des variables clés...")

fig, axes = plt.subplots(2, 3, figsize=(18, 12))
fig.suptitle(f'Distribution des Variables Agricoles - {PAYS_ANALYSE}', fontsize=18, fontweight='bold')

# Superficie
if 'area' in df.columns:
    data_area = df['area'].dropna()
    axes[0,0].hist(data_area, bins=50, edgecolor='black', color='#74c476', alpha=0.7)
    axes[0,0].axvline(data_area.median(), color='red', linestyle='--', linewidth=2, label='Médiane')
    axes[0,0].axvline(data_area.mean(), color='blue', linestyle='--', linewidth=2, label='Moyenne')
    axes[0,0].set_title('Superficie cultivée (ha)', fontweight='bold')
    axes[0,0].set_xlabel('Hectares')
    axes[0,0].set_ylabel('Fréquence')
    axes[0,0].legend()
    axes[0,0].grid(alpha=0.3)

# Production
if 'production' in df.columns:
    data_prod = df['production'].dropna()
    axes[0,1].hist(data_prod, bins=50, edgecolor='black', color='#fd8d3c', alpha=0.7)
    axes[0,1].axvline(data_prod.median(), color='red', linestyle='--', linewidth=2, label='Médiane')
    axes[0,1].axvline(data_prod.mean(), color='blue', linestyle='--', linewidth=2, label='Moyenne')
    axes[0,1].set_title('Production (tonnes)', fontweight='bold')
    axes[0,1].set_xlabel('Tonnes')
    axes[0,1].set_ylabel('Fréquence')
    axes[0,1].legend()
    axes[0,1].grid(alpha=0.3)

# Rendement
if 'yield' in df.columns:
    data_yield = df['yield'].dropna()
    axes[0,2].hist(data_yield, bins=50, edgecolor='black', color='#6baed6', alpha=0.7)
    axes[0,2].axvline(data_yield.median(), color='red', linestyle='--', linewidth=2, label='Médiane')
    axes[0,2].axvline(data_yield.mean(), color='blue', linestyle='--', linewidth=2, label='Moyenne')
    axes[0,2].set_title('Rendement (t/ha)', fontweight='bold')
    axes[0,2].set_xlabel('Tonnes/hectare')
    axes[0,2].set_ylabel('Fréquence')
    axes[0,2].legend()
    axes[0,2].grid(alpha=0.3)

# Log-scale
if 'area' in df.columns:
    data_area_log = np.log10(data_area[data_area > 0])
    axes[1,0].hist(data_area_log, bins=50, edgecolor='black', color='#74c476', alpha=0.7)
    axes[1,0].set_title('Superficie (échelle log)', fontweight='bold')
    axes[1,0].set_xlabel('Log10(Hectares)')
    axes[1,0].set_ylabel('Fréquence')
    axes[1,0].grid(alpha=0.3)

if 'production' in df.columns:
    data_prod_log = np.log10(data_prod[data_prod > 0])
    axes[1,1].hist(data_prod_log, bins=50, edgecolor='black', color='#fd8d3c', alpha=0.7)
    axes[1,1].set_title('Production (échelle log)', fontweight='bold')
    axes[1,1].set_xlabel('Log10(Tonnes)')
    axes[1,1].set_ylabel('Fréquence')
    axes[1,1].grid(alpha=0.3)

if 'yield' in df.columns:
    data_yield_log = np.log10(data_yield[data_yield > 0])
    axes[1,2].hist(data_yield_log, bins=50, edgecolor='black', color='#6baed6', alpha=0.7)
    axes[1,2].set_title('Rendement (échelle log)', fontweight='bold')
    axes[1,2].set_xlabel('Log10(t/ha)')
    axes[1,2].set_ylabel('Fréquence')
    axes[1,2].grid(alpha=0.3)

plt.tight_layout()
fig1_path = PAYS_OUTPUT_DIR / '01_distributions.png'
plt.savefig(fig1_path, dpi=300, bbox_inches='tight')
plt.close()
print(f"    ✅ Sauvegardé: 01_distributions.png")

# ============================================================================
# FIGURE 2: Cultures principales
# ============================================================================

print(f"    📊 Figure 2: Cultures principales...")

if 'product' in df.columns:
    fig, axes = plt.subplots(2, 2, figsize=(18, 14))
    fig.suptitle(f'Cultures Principales - {PAYS_ANALYSE}', fontsize=18, fontweight='bold')
    
    # Top 15 cultures par enregistrements
    product_counts = df['product'].value_counts().head(15)
    axes[0,0].barh(range(len(product_counts)), product_counts.values, color='#66c2a5')
    axes[0,0].set_yticks(range(len(product_counts)))
    axes[0,0].set_yticklabels(product_counts.index)
    axes[0,0].set_xlabel('Nombre d\'enregistrements')
    axes[0,0].set_title('Top 15 cultures par nombre d\'enregistrements', fontweight='bold')
    axes[0,0].grid(axis='x', alpha=0.3)
    axes[0,0].invert_yaxis()
    
    # Production par culture
    if 'production' in df.columns:
        prod_by_product = df.groupby('product')['production'].sum().sort_values(ascending=False).head(15)
        axes[0,1].barh(range(len(prod_by_product)), prod_by_product.values, color='#fc8d62')
        axes[0,1].set_yticks(range(len(prod_by_product)))
        axes[0,1].set_yticklabels(prod_by_product.index)
        axes[0,1].set_xlabel('Production totale (tonnes)')
        axes[0,1].set_title('Top 15 cultures par production totale', fontweight='bold')
        axes[0,1].grid(axis='x', alpha=0.3)
        axes[0,1].invert_yaxis()
    
    # Superficie par culture
    if 'area' in df.columns:
        area_by_product = df.groupby('product')['area'].sum().sort_values(ascending=False).head(15)
        axes[1,0].barh(range(len(area_by_product)), area_by_product.values, color='#8da0cb')
        axes[1,0].set_yticks(range(len(area_by_product)))
        axes[1,0].set_yticklabels(area_by_product.index)
        axes[1,0].set_xlabel('Superficie totale (ha)')
        axes[1,0].set_title('Top 15 cultures par superficie totale', fontweight='bold')
        axes[1,0].grid(axis='x', alpha=0.3)
        axes[1,0].invert_yaxis()
    
    # Rendement par culture
    if 'yield' in df.columns:
        yield_by_product = df.groupby('product')['yield'].mean().sort_values(ascending=False).head(15)
        axes[1,1].barh(range(len(yield_by_product)), yield_by_product.values, color='#e78ac3')
        axes[1,1].set_yticks(range(len(yield_by_product)))
        axes[1,1].set_yticklabels(yield_by_product.index)
        axes[1,1].set_xlabel('Rendement moyen (t/ha)')
        axes[1,1].set_title('Top 15 cultures par rendement moyen', fontweight='bold')
        axes[1,1].grid(axis='x', alpha=0.3)
        axes[1,1].invert_yaxis()
    
    plt.tight_layout()
    fig2_path = PAYS_OUTPUT_DIR / '02_cultures.png'
    plt.savefig(fig2_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"    ✅ Sauvegardé: 02_cultures.png")

# ============================================================================
# FIGURE 3: Évolution temporelle
# ============================================================================

print(f"    📊 Figure 3: Évolution temporelle...")

if 'harvest_year' in df.columns:
    fig, axes = plt.subplots(2, 2, figsize=(18, 12))
    fig.suptitle(f'Évolution Temporelle - {PAYS_ANALYSE}', fontsize=18, fontweight='bold')
    
    # Enregistrements par année
    year_counts = df['harvest_year'].value_counts().sort_index()
    axes[0,0].plot(year_counts.index, year_counts.values, marker='o', linewidth=2.5, 
                   markersize=6, color='#1f77b4')
    axes[0,0].fill_between(year_counts.index, year_counts.values, alpha=0.3, color='#1f77b4')
    axes[0,0].set_title('Nombre d\'enregistrements par année', fontweight='bold')
    axes[0,0].set_xlabel('Année')
    axes[0,0].set_ylabel('Nombre d\'enregistrements')
    axes[0,0].grid(True, alpha=0.3)
    
    # Production totale par année
    if 'production' in df.columns:
        prod_by_year = df.groupby('harvest_year')['production'].sum()
        axes[0,1].plot(prod_by_year.index, prod_by_year.values, marker='o', 
                      linewidth=2.5, markersize=6, color='#2ca02c')
        axes[0,1].fill_between(prod_by_year.index, prod_by_year.values, alpha=0.3, color='#2ca02c')
        axes[0,1].set_title('Production totale par année', fontweight='bold')
        axes[0,1].set_xlabel('Année')
        axes[0,1].set_ylabel('Production (tonnes)')
        axes[0,1].grid(True, alpha=0.3)
        
        # Tendance
        z = np.polyfit(prod_by_year.index, prod_by_year.values, 1)
        p = np.poly1d(z)
        axes[0,1].plot(prod_by_year.index, p(prod_by_year.index), 
                      "r--", alpha=0.8, linewidth=2.5, label='Tendance linéaire')
        axes[0,1].legend()
    
    # Rendement moyen par année
    if 'yield' in df.columns:
        yield_by_year = df.groupby('harvest_year')['yield'].mean()
        axes[1,0].plot(yield_by_year.index, yield_by_year.values, marker='o', 
                      linewidth=2.5, markersize=6, color='#ff7f0e')
        axes[1,0].fill_between(yield_by_year.index, yield_by_year.values, alpha=0.3, color='#ff7f0e')
        axes[1,0].set_title('Rendement moyen par année', fontweight='bold')
        axes[1,0].set_xlabel('Année')
        axes[1,0].set_ylabel('Rendement (t/ha)')
        axes[1,0].grid(True, alpha=0.3)
        
        # Tendance
        z = np.polyfit(yield_by_year.index, yield_by_year.values, 1)
        p = np.poly1d(z)
        axes[1,0].plot(yield_by_year.index, p(yield_by_year.index), 
                      "r--", alpha=0.8, linewidth=2.5, label='Tendance linéaire')
        axes[1,0].legend()
    
    # Superficie par année
    if 'area' in df.columns:
        area_by_year = df.groupby('harvest_year')['area'].sum()
        axes[1,1].plot(area_by_year.index, area_by_year.values, marker='o', 
                      linewidth=2.5, markersize=6, color='#9467bd')
        axes[1,1].fill_between(area_by_year.index, area_by_year.values, alpha=0.3, color='#9467bd')
        axes[1,1].set_title('Superficie totale par année', fontweight='bold')
        axes[1,1].set_xlabel('Année')
        axes[1,1].set_ylabel('Superficie (ha)')
        axes[1,1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    fig3_path = PAYS_OUTPUT_DIR / '03_evolution_temporelle.png'
    plt.savefig(fig3_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"    ✅ Sauvegardé: 03_evolution_temporelle.png")

# ============================================================================
# FIGURE 4: Unités administratives
# ============================================================================

print(f"    📊 Figure 4: Unités administratives...")

if 'admin_1' in df.columns:
    fig, axes = plt.subplots(2, 2, figsize=(18, 14))
    fig.suptitle(f'Analyse par Unité Administrative - {PAYS_ANALYSE}', fontsize=18, fontweight='bold')
    
    # Enregistrements par admin_1
    admin1_counts = df['admin_1'].value_counts().head(20)
    axes[0,0].barh(range(len(admin1_counts)), admin1_counts.values, color='#66c2a5')
    axes[0,0].set_yticks(range(len(admin1_counts)))
    axes[0,0].set_yticklabels(admin1_counts.index)
    axes[0,0].set_xlabel('Nombre d\'enregistrements')
    axes[0,0].set_title('Top 20 régions par enregistrements', fontweight='bold')
    axes[0,0].grid(axis='x', alpha=0.3)
    axes[0,0].invert_yaxis()
    
    # Production par admin_1
    if 'production' in df.columns:
        prod_admin1 = df.groupby('admin_1')['production'].sum().sort_values(ascending=False).head(20)
        axes[0,1].barh(range(len(prod_admin1)), prod_admin1.values, color='#fc8d62')
        axes[0,1].set_yticks(range(len(prod_admin1)))
        axes[0,1].set_yticklabels(prod_admin1.index)
        axes[0,1].set_xlabel('Production totale (tonnes)')
        axes[0,1].set_title('Top 20 régions par production', fontweight='bold')
        axes[0,1].grid(axis='x', alpha=0.3)
        axes[0,1].invert_yaxis()
    
    # Superficie par admin_1
    if 'area' in df.columns:
        area_admin1 = df.groupby('admin_1')['area'].sum().sort_values(ascending=False).head(20)
        axes[1,0].barh(range(len(area_admin1)), area_admin1.values, color='#8da0cb')
        axes[1,0].set_yticks(range(len(area_admin1)))
        axes[1,0].set_yticklabels(area_admin1.index)
        axes[1,0].set_xlabel('Superficie totale (ha)')
        axes[1,0].set_title('Top 20 régions par superficie', fontweight='bold')
        axes[1,0].grid(axis='x', alpha=0.3)
        axes[1,0].invert_yaxis()
    
    # Rendement par admin_1
    if 'yield' in df.columns:
        yield_admin1 = df.groupby('admin_1')['yield'].mean().sort_values(ascending=False).head(20)
        axes[1,1].barh(range(len(yield_admin1)), yield_admin1.values, color='#e78ac3')
        axes[1,1].set_yticks(range(len(yield_admin1)))
        axes[1,1].set_yticklabels(yield_admin1.index)
        axes[1,1].set_xlabel('Rendement moyen (t/ha)')
        axes[1,1].set_title('Top 20 régions par rendement', fontweight='bold')
        axes[1,1].grid(axis='x', alpha=0.3)
        axes[1,1].invert_yaxis()
    
    plt.tight_layout()
    fig4_path = PAYS_OUTPUT_DIR / '04_unites_administratives.png'
    plt.savefig(fig4_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"    ✅ Sauvegardé: 04_unites_administratives.png")

# ============================================================================
# FIGURE 5: Carte - Production totale
# ============================================================================

print(f"    🗺️  Figure 5: Carte de production...")

if len(gdf_enriched) > 0 and 'production_totale' in gdf_enriched.columns:
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    
    # Filtrer les géométries avec données
    gdf_plot = gdf_enriched[gdf_enriched['production_totale'].notna()].copy()
    
    if len(gdf_plot) > 0:
        # Créer la carte
        gdf_plot.plot(column='production_totale', 
                     ax=ax,
                     legend=True,
                     cmap='YlOrRd',
                     edgecolor='black',
                     linewidth=0.5,
                     legend_kwds={'label': 'Production totale (tonnes)',
                                 'orientation': 'horizontal',
                                 'shrink': 0.8,
                                 'pad': 0.05})
        
        # Ajouter les limites sans données
        gdf_enriched[gdf_enriched['production_totale'].isna()].plot(ax=ax,
                                                                     color='lightgray',
                                                                     edgecolor='black',
                                                                     linewidth=0.5,
                                                                     alpha=0.5)
        
        ax.set_title(f'Production Totale par Région - {PAYS_ANALYSE}', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.set_xlabel('Longitude', fontsize=12)
        ax.set_ylabel('Latitude', fontsize=12)
        ax.grid(True, alpha=0.3, linestyle='--')
        
        plt.tight_layout()
        fig5_path = PAYS_OUTPUT_DIR / '05_carte_production.png'
        plt.savefig(fig5_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"    ✅ Sauvegardé: 05_carte_production.png")
    else:
        plt.close()
        print(f"    ⚠️  Pas de données de production à cartographier")
else:
    print(f"    ⚠️  Données géographiques insuffisantes pour la carte de production")

# ============================================================================
# FIGURE 6: Carte - Rendement moyen
# ============================================================================

print(f"    🗺️  Figure 6: Carte de rendement...")

if len(gdf_enriched) > 0 and 'rendement_moyen' in gdf_enriched.columns:
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    
    gdf_plot = gdf_enriched[gdf_enriched['rendement_moyen'].notna()].copy()
    
    if len(gdf_plot) > 0:
        gdf_plot.plot(column='rendement_moyen',
                     ax=ax,
                     legend=True,
                     cmap='Blues',
                     edgecolor='black',
                     linewidth=0.5,
                     legend_kwds={'label': 'Rendement moyen (t/ha)',
                                 'orientation': 'horizontal',
                                 'shrink': 0.8,
                                 'pad': 0.05})
        
        gdf_enriched[gdf_enriched['rendement_moyen'].isna()].plot(ax=ax,
                                                                   color='lightgray',
                                                                   edgecolor='black',
                                                                   linewidth=0.5,
                                                                   alpha=0.5)
        
        ax.set_title(f'Rendement Moyen par Région - {PAYS_ANALYSE}', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.set_xlabel('Longitude', fontsize=12)
        ax.set_ylabel('Latitude', fontsize=12)
        ax.grid(True, alpha=0.3, linestyle='--')
        
        plt.tight_layout()
        fig6_path = PAYS_OUTPUT_DIR / '06_carte_rendement.png'
        plt.savefig(fig6_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"    ✅ Sauvegardé: 06_carte_rendement.png")
    else:
        plt.close()
        print(f"    ⚠️  Pas de données de rendement à cartographier")
else:
    print(f"    ⚠️  Données géographiques insuffisantes pour la carte de rendement")

# ============================================================================
# FIGURE 7: Carte - Superficie totale
# ============================================================================

print(f"    🗺️  Figure 7: Carte de superficie...")

if len(gdf_enriched) > 0 and 'superficie_totale' in gdf_enriched.columns:
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    
    gdf_plot = gdf_enriched[gdf_enriched['superficie_totale'].notna()].copy()
    
    if len(gdf_plot) > 0:
        gdf_plot.plot(column='superficie_totale',
                     ax=ax,
                     legend=True,
                     cmap='Greens',
                     edgecolor='black',
                     linewidth=0.5,
                     legend_kwds={'label': 'Superficie totale (ha)',
                                 'orientation': 'horizontal',
                                 'shrink': 0.8,
                                 'pad': 0.05})
        
        gdf_enriched[gdf_enriched['superficie_totale'].isna()].plot(ax=ax,
                                                                     color='lightgray',
                                                                     edgecolor='black',
                                                                     linewidth=0.5,
                                                                     alpha=0.5)
        
        ax.set_title(f'Superficie Totale Cultivée par Région - {PAYS_ANALYSE}', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.set_xlabel('Longitude', fontsize=12)
        ax.set_ylabel('Latitude', fontsize=12)
        ax.grid(True, alpha=0.3, linestyle='--')
        
        plt.tight_layout()
        fig7_path = PAYS_OUTPUT_DIR / '07_carte_superficie.png'
        plt.savefig(fig7_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"    ✅ Sauvegardé: 07_carte_superficie.png")
    else:
        plt.close()
        print(f"    ⚠️  Pas de données de superficie à cartographier")
else:
    print(f"    ⚠️  Données géographiques insuffisantes pour la carte de superficie")

# ============================================================================
# FIGURE 8: Carte - Vue d'ensemble avec limites administratives
# ============================================================================

print(f"    🗺️  Figure 8: Carte des limites administratives...")

if len(gdf) > 0:
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    
    # Tracer toutes les limites
    gdf.plot(ax=ax,
             facecolor='#e8f4f8',
             edgecolor='#2c5f77',
             linewidth=1.2,
             alpha=0.7)
    
    # Ajouter les étiquettes pour les principales régions (admin_1)
    if 'admin_1' in gdf.columns:
        # Calculer les centroïdes
        gdf_temp = gdf.copy()
        gdf_temp['centroid'] = gdf_temp.geometry.centroid
        
        # Grouper par admin_1 et prendre le premier centroïde
        unique_admin1 = gdf_temp.groupby('admin_1').first()
        
        # Limiter aux 10 plus grandes régions
        admin1_sizes = gdf_temp.groupby('admin_1').size().sort_values(ascending=False).head(10)
        
        for admin in admin1_sizes.index:
            if admin in unique_admin1.index:
                centroid = unique_admin1.loc[admin, 'centroid']
                ax.annotate(admin, 
                           xy=(centroid.x, centroid.y),
                           fontsize=9,
                           ha='center',
                           bbox=dict(boxstyle='round,pad=0.5', 
                                   facecolor='white', 
                                   edgecolor='gray',
                                   alpha=0.8))
    
    ax.set_title(f'Limites Administratives - {PAYS_ANALYSE}', 
                fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('Longitude', fontsize=12)
    ax.set_ylabel('Latitude', fontsize=12)
    ax.grid(True, alpha=0.3, linestyle='--')
    
    plt.tight_layout()
    fig8_path = PAYS_OUTPUT_DIR / '08_carte_limites.png'
    plt.savefig(fig8_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"    ✅ Sauvegardé: 08_carte_limites.png")
else:
    print(f"    ⚠️  Données géographiques insuffisantes")

# ============================================================================
# ÉTAPE 11: EXPORT DES DONNÉES AGRÉGÉES
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 11: EXPORT DES DONNÉES AGRÉGÉES - {PAYS_ANALYSE}")
print("="*90)

print(f"\n11.1 Création des fichiers CSV agrégés...")

# Par culture
if 'product' in df.columns:
    stats_culture = df.groupby('product').agg({
        'production': ['sum', 'mean', 'std'],
        'area': ['sum', 'mean', 'std'],
        'yield': ['mean', 'median', 'std'],
        'fnid': 'count'
    }).round(2)
    stats_culture.columns = ['_'.join(col) for col in stats_culture.columns]
    stats_culture = stats_culture.rename(columns={'fnid_count': 'nb_enregistrements'})
    
    csv_culture = PAYS_OUTPUT_DIR / f'{PAYS_ANALYSE}_stats_par_culture.csv'
    stats_culture.to_csv(csv_culture)
    print(f"    ✅ Exporté: {csv_culture.name}")

# Par région (admin_1)
if 'admin_1' in df.columns:
    stats_admin1 = df.groupby('admin_1').agg({
        'production': ['sum', 'mean', 'std'],
        'area': ['sum', 'mean', 'std'],
        'yield': ['mean', 'median', 'std'],
        'fnid': 'count'
    }).round(2)
    stats_admin1.columns = ['_'.join(col) for col in stats_admin1.columns]
    stats_admin1 = stats_admin1.rename(columns={'fnid_count': 'nb_enregistrements'})
    
    csv_admin1 = PAYS_OUTPUT_DIR / f'{PAYS_ANALYSE}_stats_par_region.csv'
    stats_admin1.to_csv(csv_admin1)
    print(f"    ✅ Exporté: {csv_admin1.name}")

# Par année
if 'harvest_year' in df.columns:
    stats_annee = df.groupby('harvest_year').agg({
        'production': 'sum',
        'area': 'sum',
        'yield': 'mean',
        'fnid': 'count'
    }).round(2)
    stats_annee.columns = ['production_totale', 'superficie_totale', 'rendement_moyen', 'nb_enregistrements']
    
    csv_annee = PAYS_OUTPUT_DIR / f'{PAYS_ANALYSE}_evolution_temporelle.csv'
    stats_annee.to_csv(csv_annee)
    print(f"    ✅ Exporté: {csv_annee.name}")

# ============================================================================
# ÉTAPE 12: GÉNÉRATION DU RAPPORT
# ============================================================================

print("\n" + "="*90)
print(f"ÉTAPE 12: GÉNÉRATION DU RAPPORT FINAL - {PAYS_ANALYSE}")
print("="*90)

print(f"\n12.1 Création du rapport PDF/Texte...")

rapport = f"""
{'='*90}
RAPPORT D'ANALYSE AGRICOLE - {PAYS_ANALYSE}
{'='*90}

Date de génération: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
Source: HarvestStat Africa v1.0
Dataset: USAID FEWS NET

{'='*90}
1. SYNTHÈSE EXÉCUTIVE
{'='*90}

Nombre total d'enregistrements: {len(df):,}
Période couverte: {df['harvest_year'].min():.0f} - {df['harvest_year'].max():.0f}
Nombre de cultures: {df['product'].nunique() if 'product' in df.columns else 'N/A'}
Nombre de régions (admin_1): {df['admin_1'].nunique() if 'admin_1' in df.columns else 'N/A'}
Nombre de districts (admin_2): {df['admin_2'].nunique() if 'admin_2' in df.columns else 'N/A'}

{'='*90}
2. STATISTIQUES AGRICOLES GLOBALES
{'='*90}

PRODUCTION:
  • Totale: {df['production'].sum():,.0f} tonnes
  • Moyenne: {df['production'].mean():,.2f} tonnes
  • Médiane: {df['production'].median():,.2f} tonnes
  • Écart-type: {df['production'].std():,.2f} tonnes

SUPERFICIE:
  • Totale: {df['area'].sum():,.0f} hectares
  • Moyenne: {df['area'].mean():,.2f} hectares
  • Médiane: {df['area'].median():,.2f} hectares
  • Écart-type: {df['area'].std():,.2f} hectares

RENDEMENT:
  • Moyen: {df['yield'].mean():.2f} t/ha
  • Médian: {df['yield'].median():.2f} t/ha
  • Écart-type: {df['yield'].std():.2f} t/ha
  • Minimum: {df['yield'].min():.2f} t/ha
  • Maximum: {df['yield'].max():.2f} t/ha

{'='*90}
3. TOP 10 CULTURES
{'='*90}

Par production totale:
"""

if 'product' in df.columns and 'production' in df.columns:
    prod_top = df.groupby('product')['production'].sum().sort_values(ascending=False).head(10)
    for i, (culture, prod) in enumerate(prod_top.items(), 1):
        rapport += f"{i:2d}. {culture:40s} : {prod:15,.0f} tonnes\n"

rapport += f"\nPar superficie totale:\n"
if 'product' in df.columns and 'area' in df.columns:
    area_top = df.groupby('product')['area'].sum().sort_values(ascending=False).head(10)
    for i, (culture, area) in enumerate(area_top.items(), 1):
        rapport += f"{i:2d}. {culture:40s} : {area:15,.0f} hectares\n"

rapport += f"\nPar rendement moyen:\n"
if 'product' in df.columns and 'yield' in df.columns:
    yield_top = df.groupby('product')['yield'].mean().sort_values(ascending=False).head(10)
    for i, (culture, yld) in enumerate(yield_top.items(), 1):
        rapport += f"{i:2d}. {culture:40s} : {yld:8.2f} t/ha\n"

rapport += f"""
{'='*90}
4. TOP 10 RÉGIONS (ADMIN_1)
{'='*90}

Par production totale:
"""

if 'admin_1' in df.columns and 'production' in df.columns:
    admin1_prod = df.groupby('admin_1')['production'].sum().sort_values(ascending=False).head(10)
    for i, (region, prod) in enumerate(admin1_prod.items(), 1):
        rapport += f"{i:2d}. {region:40s} : {prod:15,.0f} tonnes\n"

rapport += f"""
{'='*90}
5. ÉVOLUTION TEMPORELLE
{'='*90}
"""

if 'harvest_year' in df.columns:
    if 'production' in df.columns:
        prod_year = df.groupby('harvest_year')['production'].sum()
        if len(prod_year) > 1:
            croissance = ((prod_year.iloc[-1] - prod_year.iloc[0]) / prod_year.iloc[0]) * 100
            rapport += f"\nProduction:\n"
            rapport += f"  • Première année ({prod_year.index[0]:.0f}): {prod_year.iloc[0]:,.0f} tonnes\n"
            rapport += f"  • Dernière année ({prod_year.index[-1]:.0f}): {prod_year.iloc[-1]:,.0f} tonnes\n"
            rapport += f"  • Croissance totale: {croissance:+.2f}%\n"
    
    if 'yield' in df.columns:
        yield_year = df.groupby('harvest_year')['yield'].mean()
        if len(yield_year) > 1:
            evolution = ((yield_year.iloc[-1] - yield_year.iloc[0]) / yield_year.iloc[0]) * 100
            rapport += f"\nRendement:\n"
            rapport += f"  • Première année ({yield_year.index[0]:.0f}): {yield_year.iloc[0]:.2f} t/ha\n"
            rapport += f"  • Dernière année ({yield_year.index[-1]:.0f}): {yield_year.iloc[-1]:.2f} t/ha\n"
            rapport += f"  • Évolution totale: {evolution:+.2f}%\n"

rapport += f"""
{'='*90}
6. QUALITÉ DES DONNÉES
{'='*90}
"""

if 'qc_flag' in df.columns:
    qc_counts = df['qc_flag'].value_counts()
    rapport += f"\nIndicateurs de qualité (QC Flag):\n"
    rapport += f"  • Données valides (0): {qc_counts.get(0, 0):,} ({qc_counts.get(0, 0)/len(df)*100:.2f}%)\n"
    rapport += f"  • Valeurs aberrantes (1): {qc_counts.get(1, 0):,} ({qc_counts.get(1, 0)/len(df)*100:.2f}%)\n"
    rapport += f"  • Faible variance (2): {qc_counts.get(2, 0):,} ({qc_counts.get(2, 0)/len(df)*100:.2f}%)\n"

missing_total = df.isna().sum().sum()
missing_pct = missing_total / (len(df) * len(df.columns)) * 100
rapport += f"\nValeurs manquantes:\n"
rapport += f"  • Total: {missing_total:,} ({missing_pct:.2f}%)\n"
rapport += f"  • Enregistrements complets: {df.notna().all(axis=1).sum():,} ({df.notna().all(axis=1).sum()/len(df)*100:.2f}%)\n"

rapport += f"""
{'='*90}
7. FICHIERS GÉNÉRÉS
{'='*90}

GRAPHIQUES (PNG 300 DPI):
  ✓ 01_distributions.png
  ✓ 02_cultures.png
  ✓ 03_evolution_temporelle.png
  ✓ 04_unites_administratives.png
  ✓ 05_carte_production.png
  ✓ 06_carte_rendement.png
  ✓ 07_carte_superficie.png
  ✓ 08_carte_limites.png

DONNÉES (CSV):
  ✓ {PAYS_ANALYSE}_stats_par_culture.csv
  ✓ {PAYS_ANALYSE}_stats_par_region.csv
  ✓ {PAYS_ANALYSE}_evolution_temporelle.csv

GÉOGRAPHIQUE (GeoPackage):
  ✓ {PAYS_ANALYSE}_enriched.gpkg

{'='*90}
FIN DU RAPPORT
{'='*90}
"""

# Sauvegarder le rapport
rapport_path = PAYS_OUTPUT_DIR / f'{PAYS_ANALYSE}_rapport_complet.txt'
with open(rapport_path, 'w', encoding='utf-8') as f:
    f.write(rapport)

print(f"    ✅ Rapport sauvegardé: {rapport_path.name}")

# ============================================================================
# FIN DE L'ANALYSE
# ============================================================================

print("\n" + "="*90)
print("ANALYSE TERMINÉE AVEC SUCCÈS")
print("="*90)

print(f"""
✅ Analyse complète de {PAYS_ANALYSE} terminée!

📁 Tous les fichiers sont dans: {PAYS_OUTPUT_DIR}

📊 Fichiers générés:
   • 8 graphiques PNG (haute résolution)
   • 3 fichiers CSV de statistiques
   • 1 GeoPackage enrichi
   • 1 rapport texte complet

🎯 Prochaines étapes suggérées:
   • Examiner les cartes pour identifier les zones à fort potentiel
   • Analyser les tendances temporelles pour comprendre l'évolution
   • Comparer avec d'autres pays de la région
   • Approfondir l'analyse des cultures principales

📧 Pour toute question sur cette analyse, consultez le rapport complet.
""")

print("="*90)